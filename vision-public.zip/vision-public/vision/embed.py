"""The embedding model, loaded lazily so commands that don't embed
(like `vision --help`) don't pay the multi-second torch import."""
import threading

MODEL_NAME = "BAAI/bge-small-en-v1.5"
DIM = 384
# bge models are trained to put this before *queries* (not documents).
QUERY_PREFIX = "Represent this sentence for searching relevant passages: "

_model = None
_lock = threading.Lock()  # the MCP server may load it from two threads


def get_model():
    global _model
    with _lock:
        if _model is None:
            from sentence_transformers import SentenceTransformer
            try:
                # Use the cached copy without touching the network.
                _model = SentenceTransformer(MODEL_NAME, local_files_only=True)
            except Exception:
                # First run: download once, then it's cached.
                _model = SentenceTransformer(MODEL_NAME)
    return _model


def embed_documents(texts, progress=False):
    return get_model().encode(
        texts, normalize_embeddings=True, show_progress_bar=progress)


def embed_query(query, use_prefix=True):
    text = QUERY_PREFIX + query if use_prefix else query
    return get_model().encode(text, normalize_embeddings=True)
