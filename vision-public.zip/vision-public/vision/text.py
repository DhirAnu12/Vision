"""Pure text helpers: splitting identifiers into words, expanding
abbreviations, and turning a user query into a safe FTS5 query."""
import re

# Abbreviations that show up in code but that people don't type when
# searching. If a chunk contains the key as a word, the expansion is added
# to its searchable text, so "speech to text" can find `_build_stt`.
# Edit freely - re-run `vision index` afterwards.
ABBREVIATIONS = {
    "stt": "speech to text",
    "tts": "text to speech",
    "asr": "speech recognition",
    "vad": "voice activity detection",
    "llm": "language model",
    "nlp": "natural language processing",
    "db": "database",
    "sql": "database query",
    "auth": "authentication login",
    "cfg": "config configuration",
    "conf": "config configuration",
    "env": "environment",
    "ctx": "context",
    "msg": "message",
    "req": "request",
    "resp": "response",
    "err": "error",
    "exc": "exception error",
    "img": "image",
    "btn": "button",
    "ui": "user interface",
    "hud": "heads up display overlay",
    "api": "interface endpoint",
    "url": "link address",
    "http": "web request",
    "ws": "websocket",
    "dir": "directory folder",
    "tmp": "temporary",
    "fn": "function",
    "args": "arguments",
    "kwargs": "keyword arguments",
    "init": "initialize setup",
    "util": "utility helper",
    "utils": "utility helper",
    "repo": "repository",
    "mcp": "model context protocol tool server",
}

# Words too common to help keyword search.
STOPWORDS = {
    "a", "an", "the", "to", "of", "in", "on", "for", "and", "or", "is",
    "it", "be", "by", "with", "from", "at", "as", "that", "this", "how",
    "what", "where", "which", "does", "do", "i", "we", "my", "get", "code",
}

_IDENT = re.compile(r"[A-Za-z0-9]+")  # underscores and symbols split words
_CAMEL = re.compile(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|\d+")


def split_words(text):
    """'_build_stt' -> ['build', 'stt'];  'HTTPServer' -> ['http', 'server']"""
    words = []
    for token in _IDENT.findall(text):
        words.extend(w.lower() for w in _CAMEL.findall(token))
    return words


def expansions(text):
    """Expansions for every abbreviation that appears as a word in text."""
    found = set(split_words(text)) & ABBREVIATIONS.keys()
    return [ABBREVIATIONS[w] for w in sorted(found)]


def fts_query(query):
    """Turn free text into an FTS5 query like
    '"speech to text" OR "speech" OR "text"'.

    The first part is the whole query as a phrase (words adjacent, in
    order): without it "speech to text" and "text to speech" look the same.
    Then each word on its own, minus stopwords. Words are quoted so
    characters like '-' or '*' can't break FTS5 syntax. OR (not AND)
    because a chunk matching only some words should still be found; BM25
    ranks chunks matching more/rarer terms higher.
    Returns None if nothing searchable is left.
    """
    all_words = split_words(query)
    words = list(dict.fromkeys(w for w in all_words if w not in STOPWORDS))
    if not words:
        return None
    parts = [f'"{w}"' for w in words]
    if len(all_words) > 1:
        parts.insert(0, '"' + " ".join(all_words) + '"')
    return " OR ".join(parts)
