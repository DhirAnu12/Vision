"""Watch mode: keep the index in sync while you edit, re-indexing only the
files that change."""
import queue
from pathlib import Path

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from . import db as vdb
from .indexer import (file_status, index_file, index_repo, is_indexable,
                      norm_path, refresh_file, remove_file)

DEBOUNCE_SECONDS = 0.5


class _Enqueue(FileSystemEventHandler):
    """Runs on watchdog's thread: only records paths, never touches sqlite."""

    def __init__(self, q):
        self.q = q

    def on_any_event(self, event):
        if event.event_type in ("opened", "closed", "closed_no_write"):
            return
        for p in (event.src_path, getattr(event, "dest_path", None)):
            if p:
                self.q.put((norm_path(p), event.is_directory))


def apply_changes(db, root, paths):
    """Bring the given paths up to date. A path may be a file or a folder
    (a deleted or moved-in folder arrives as one event, not one per file).
    Returns a list of human-readable change descriptions."""
    log = []
    for path, is_dir in sorted(paths):
        p = Path(path)
        if is_dir or p.is_dir():
            if not is_indexable(p / "x.py", root):
                continue  # inside venv/.git/...: don't walk it
            # deleted folder: drop everything we had under it
            for f in vdb.tracked_files(db, under=path):
                if not Path(f).exists():
                    log.append(f"removed {f} ({remove_file(db, f)} functions)")
            # new/moved-in folder: index what's inside
            if p.is_dir():
                for f in p.rglob("*.py"):
                    if is_indexable(f, root) and file_status(db, f) != "fresh":
                        s = index_file(db, f)
                        log.append(f"indexed {norm_path(f)} (+{s['added']} functions)")
        elif is_indexable(p, root) and file_status(db, path) != "fresh":
            s = refresh_file(db, path)
            if p.is_file():
                log.append(f"updated {path} (+{s['added']} -{s['removed']}"
                           f" ={s['kept']} functions)")
            else:
                log.append(f"removed {path} ({s['removed']} functions)")
    db.commit()
    return log


def watch(root, db_path=None, stop=None, on_log=print,
          debounce=DEBOUNCE_SECONDS, name=None):
    """Block and keep `root` indexed until `stop` (a threading.Event) is set
    or Ctrl+C. Starts with a sync so edits made while not watching count."""
    root = Path(norm_path(root))
    db = vdb.connect(db_path)
    stats = index_repo(root, db, name=name, progress=False)
    on_log(f"watching {stats['repo']} at {root} ({stats['chunks']} functions; caught up on "
           f"{stats['changed']} changed, {stats['deleted']} deleted files)")

    q = queue.Queue()
    observer = Observer()
    observer.schedule(_Enqueue(q), str(root), recursive=True)
    observer.start()
    pending = set()
    try:
        while stop is None or not stop.is_set():
            try:
                pending.add(q.get(timeout=debounce))
                continue  # keep collecting until things go quiet
            except queue.Empty:
                pass
            if pending:
                for line in apply_changes(db, root, pending):
                    on_log(line)
                pending.clear()
    except KeyboardInterrupt:
        pass
    finally:
        observer.stop()
        observer.join()
        db.close()
