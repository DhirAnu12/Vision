"""Search quality benchmark: run labelled queries under several search
configurations and report hit@5, recall@5 and MRR as markdown."""
import json
import time
from datetime import date

from .embed import get_model
from .search import search

K = 5          # cut-off for hit@K and recall@K
MRR_DEPTH = 10  # first relevant result beyond this rank counts as a miss

CONFIGS = {
    "vector, no prefix": {"mode": "vector", "use_prefix": False},
    "vector + prefix":   {"mode": "vector", "use_prefix": True},
    "hybrid, no prefix": {"mode": "hybrid", "use_prefix": False},
    "hybrid + prefix":   {"mode": "hybrid", "use_prefix": True},   # the default
    "keyword only":      {"mode": "keyword", "use_prefix": True},  # reference
}
DEFAULT = "hybrid + prefix"


# ---- metrics (pure) ----------------------------------------------------------

def first_rank(ranked, relevant):
    """1-based rank of the first relevant name, or None."""
    for i, name in enumerate(ranked, start=1):
        if name in relevant:
            return i
    return None


def hit_at(ranked, relevant, k=K):
    return any(name in relevant for name in ranked[:k])


def recall_at(ranked, relevant, k=K):
    """Share of relevant items found in the top k. The denominator is capped
    at k, so a query with 6 right answers can still score 1.0 at k=5."""
    found = len(set(ranked[:k]) & set(relevant))
    return found / min(len(relevant), k)


def reciprocal_rank(ranked, relevant, depth=MRR_DEPTH):
    r = first_rank(ranked[:depth], relevant)
    return 1.0 / r if r else 0.0


# ---- running -----------------------------------------------------------------

def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def validate(db, bench):
    """Every expected answer must exist, or a typo would look like a miss."""
    known = {r[0] for r in db.execute(
        "SELECT DISTINCT qualname FROM chunks WHERE kind = 'code' AND repo = ?",
        (bench["repo"],))}
    missing = sorted({n for q in bench["queries"] for n in q["relevant"]} - known)
    if missing:
        raise ValueError(f"not in repo {bench['repo']!r}: {', '.join(missing)}")


def ranked_names(db, query, repo, **kwargs):
    """Distinct function names in rank order (copies are already folded)."""
    results = search(db, query, k=MRR_DEPTH, repo=repo, refresh=False, **kwargs)
    names = []
    for r in results:
        if r.kind == "code" and r.verdict != "DEAD" and r.name not in names:
            names.append(r.name)
    return names


def run(db, bench, configs=CONFIGS):
    """{config: {"rows": [per-query dicts], "ms": mean ms per query}}"""
    validate(db, bench)
    get_model()  # load before timing, or the first config pays for it
    out = {}
    for name, kwargs in configs.items():
        rows, start = [], time.perf_counter()
        for q in bench["queries"]:
            ranked = ranked_names(db, q["query"], bench["repo"], **kwargs)
            rel = set(q["relevant"])
            rows.append({**q, "ranked": ranked,
                         "rank": first_rank(ranked, rel),
                         "hit": hit_at(ranked, rel),
                         "recall": recall_at(ranked, rel),
                         "rr": reciprocal_rank(ranked, rel)})
        ms = (time.perf_counter() - start) * 1000 / len(bench["queries"])
        out[name] = {"rows": rows, "ms": ms}
    return out


def summarize(rows):
    n = len(rows)
    if n == 0:
        return {"n": 0, "hit": 0.0, "recall": 0.0, "mrr": 0.0}
    return {"n": n,
            "hit": sum(r["hit"] for r in rows) / n,
            "recall": sum(r["recall"] for r in rows) / n,
            "mrr": sum(r["rr"] for r in rows) / n}


# ---- report ------------------------------------------------------------------

def _f(x):
    return f"{x:.2f}"


def report(bench, results, notes=""):
    configs = list(results)
    types = sorted({q["type"] for q in bench["queries"]})
    counts = ", ".join(f"{sum(q['type'] == t for q in bench['queries'])} {t}"
                       for t in types)
    lines = [f"# Vision search benchmark: {bench['repo']}", "",
             f"{date.today().isoformat()} · {len(bench['queries'])} queries"
             f" ({counts}) · hit@{K}, recall@{K}, MRR@{MRR_DEPTH}", ""]
    if notes:
        lines += [notes.strip(), ""]

    lines += ["## Results", "",
              f"| Configuration | hit@{K} | recall@{K} | MRR | ms/query |",
              "|---|---|---|---|---|"]
    for c in configs:
        s = summarize(results[c]["rows"])
        bold = "**" if c == DEFAULT else ""
        lines.append(f"| {bold}{c}{bold} | {_f(s['hit'])} | {_f(s['recall'])} |"
                     f" {_f(s['mrr'])} | {results[c]['ms']:.0f} |")
    lines.append("")

    for t in types:
        lines += [f"### {t.capitalize()} queries only", "",
                  f"| Configuration | hit@{K} | recall@{K} | MRR |", "|---|---|---|---|"]
        for c in configs:
            s = summarize([r for r in results[c]["rows"] if r["type"] == t])
            lines.append(f"| {c} | {_f(s['hit'])} | {_f(s['recall'])} | {_f(s['mrr'])} |")
        lines.append("")

    lines += ["## Per query", "",
              "Rank of the first correct result (— = not in top "
              f"{MRR_DEPTH}).", "",
              "| # | Type | Query | " + " | ".join(configs) + " |",
              "|---|---|---|" + "---|" * len(configs)]
    for i, q in enumerate(bench["queries"]):
        ranks = [results[c]["rows"][i]["rank"] for c in configs]
        cells = [str(r) if r else "—" for r in ranks]
        lines.append(f"| {i + 1} | {q['type'][:5]} | {q['query']} | " + " | ".join(cells) + " |")
    lines.append("")

    misses = [r for r in results[DEFAULT]["rows"] if not r["hit"]] if DEFAULT in results else []
    lines += [f"## Misses with the default ({DEFAULT})", ""]
    if not misses:
        lines.append(f"None: every query had a correct answer in the top {K}.")
    for r in misses:
        lines += [f"- **{r['query']}**: wanted {', '.join(f'`{n}`' for n in r['relevant'])};"
                  f" got {', '.join(f'`{n}`' for n in r['ranked'][:3]) or 'nothing'}"]
    lines.append("")
    return "\n".join(lines)
