"""Vision: a local memory/search layer for AI coding agents."""
