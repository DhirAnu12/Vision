"""SQLite storage: one row per item in `chunks`, plus two search indexes
that share its id - `vec_chunks` (vectors) and `chunks_fts` (keywords).

An item is either kind='code' (a function; rebuilt by `vision index`) or
kind='note' (written with `remember`; can't be regenerated, so it is never
deleted by re-indexing and survives schema changes).

Several repos can live in one database: every code row and file record
carries its repo's name. Notes have repo '' (global, shown for any repo).
"""
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import sqlite_vec

from .embed import DIM

# Bump when the table layout changes; older databases get rebuilt
# (code is re-indexed by the user, notes are carried over automatically).
SCHEMA_VERSION = 8
NOTE_REPO = ""  # notes belong to no repo


def default_db_path():
    return os.environ.get("VISION_DB", "vision.db")


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect(path=None):
    # timeout: if another process (watch mode, the MCP server) is writing,
    # wait up to 30s for its lock instead of failing immediately.
    db = sqlite3.connect(path or default_db_path(), timeout=30)
    db.row_factory = sqlite3.Row
    # WAL lets readers keep reading while one writer writes.
    db.execute("PRAGMA journal_mode = WAL")
    db.enable_load_extension(True)
    sqlite_vec.load(db)
    db.enable_load_extension(False)
    if db.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
        notes = _salvage_notes(db)
        _create_schema(db)
        for note in notes:
            insert_note(db, note["text"], note["tags"], note["created_at"])
        db.commit()
    return db


def _salvage_notes(db):
    """Read notes out of an older schema before its tables are dropped."""
    cols = {r[1] for r in db.execute("PRAGMA table_info(chunks)")}
    if "kind" not in cols:
        return []  # schemas before v4 had no notes
    rows = db.execute("SELECT code, tags, created_at FROM chunks"
                      " WHERE kind = 'note' ORDER BY id").fetchall()
    return [{"text": r[0], "tags": split_tags(r[1]), "created_at": r[2]}
            for r in rows]


def _create_schema(db):
    for table in ("chunks", "vec_chunks", "chunks_fts", "meta", "files",
                  "repos", "calls", "imports"):
        db.execute(f"DROP TABLE IF EXISTS {table}")
    db.executescript(f"""
        CREATE TABLE repos(name TEXT PRIMARY KEY, root TEXT UNIQUE,
                           indexed_at TEXT);
        CREATE TABLE chunks(
            id INTEGER PRIMARY KEY,
            kind TEXT NOT NULL DEFAULT 'code',   -- 'code' or 'note'
            repo TEXT NOT NULL DEFAULT '',       -- '' for notes
            file TEXT, name TEXT, qualname TEXT,
            start_line INT, end_line INT,
            code TEXT,                           -- function source / note text
            code_hash TEXT,                      -- sha256 of code
            tags TEXT, created_at TEXT);         -- notes only
        CREATE INDEX chunks_kind ON chunks(kind);
        CREATE INDEX chunks_file ON chunks(file);
        CREATE INDEX chunks_copy ON chunks(qualname, code_hash);
        CREATE INDEX chunks_name ON chunks(repo, name);
        -- What each file looked like when it was indexed. mtime+size is a
        -- cheap "did it change?" check; sha256 is the real answer.
        CREATE TABLE files(
            path TEXT PRIMARY KEY, repo TEXT, sha256 TEXT,
            mtime_ns INT, size INT, indexed_at TEXT);
        -- Call sites exactly as written in the caller ('self.save(...)' ->
        -- name 'save', kind 'self'). Resolved to functions at query time.
        -- line_offset is relative to the caller's first line, so it stays
        -- right when the caller merely moves within its file.
        CREATE TABLE calls(
            caller_id INT, name TEXT, obj TEXT, kind TEXT, line_offset INT);
        CREATE INDEX calls_caller ON calls(caller_id);
        CREATE INDEX calls_name ON calls(name);
        -- Names a file imports, so calls can be resolved through them:
        -- 'from vision.search import search as s' -> local 's',
        -- module 'vision.search', name 'search'. `import x.y` -> local 'x',
        -- module 'x', name NULL. Relative modules keep their dots ('.search').
        CREATE TABLE imports(file TEXT, local TEXT, module TEXT, name TEXT);
        CREATE INDEX imports_file ON imports(file, local);
        -- repo is a metadata column: KNN can filter on it while searching.
        CREATE VIRTUAL TABLE vec_chunks USING vec0(
            embedding float[{DIM}], repo text);
        -- name: code: 'VoiceAgent.__init__ voice agent init initialize setup'
        --   (qualname + its split words + their abbreviation expansions);
        --   note: its tags (+ expansions). Abbreviations used only in the
        --   body are NOT expanded here: 'text to speech' added to every
        --   function using `tts` made "text" queries match them.
        CREATE VIRTUAL TABLE chunks_fts USING fts5(name, code);
        CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);
        PRAGMA user_version = {SCHEMA_VERSION};
    """)
    db.commit()


# ---- repos -----------------------------------------------------------------

def default_repo_name(root):
    """'C:/Code/My Project' -> 'my-project'"""
    return re.sub(r"[^a-z0-9_.-]+", "-", Path(root).name.lower()).strip("-") or "repo"


def _inside(a, b):
    """Is folder a inside folder b (or the same)?"""
    return os.path.join(a, "").startswith(os.path.join(b, ""))


def add_repo(db, name, root):
    """Register (or re-confirm) a repo. Refuses a name already used for a
    different folder, and folders nested in each other (a file must belong
    to exactly one repo)."""
    for r in get_repos(db):
        if r["name"] == name and r["root"] == root:
            break
        if r["name"] == name:
            raise ValueError(f"repo name {name!r} is already used for {r['root']};"
                             " pick another with --name")
        if r["root"] == root:
            raise ValueError(f"{root} is already indexed as {r['name']!r}")
        if _inside(root, r["root"]) or _inside(r["root"], root):
            raise ValueError(f"{root} overlaps repo {r['name']!r} ({r['root']})")
    db.execute("INSERT OR REPLACE INTO repos(name, root, indexed_at)"
               " VALUES (?, ?, ?)", (name, root, _now()))


def get_repos(db):
    return db.execute("SELECT * FROM repos ORDER BY name").fetchall()


def repo_for_path(db, path):
    """Name of the repo whose folder contains path, or None."""
    for r in get_repos(db):
        if _inside(str(path), r["root"]):
            return r["name"]
    return None


def remove_repo(db, name):
    n = clear_code(db, name)
    db.execute("DELETE FROM repos WHERE name = ?", (name,))
    return n


# ---- code chunks -----------------------------------------------------------

def clear_code(db, repo):
    """Delete one repo's code chunks and file records (notes are kept)."""
    ids = [r[0] for r in db.execute(
        "SELECT id FROM chunks WHERE kind = 'code' AND repo = ?", (repo,))]
    delete_chunks(db, ids)
    db.execute("DELETE FROM imports WHERE file IN"
               " (SELECT path FROM files WHERE repo = ?)", (repo,))
    db.execute("DELETE FROM files WHERE repo = ?", (repo,))
    return len(ids)


def delete_chunks(db, ids):
    for chunk_id in ids:
        db.execute("DELETE FROM vec_chunks WHERE rowid = ?", (chunk_id,))
        db.execute("DELETE FROM chunks_fts WHERE rowid = ?", (chunk_id,))
        db.execute("DELETE FROM calls WHERE caller_id = ?", (chunk_id,))
        db.execute("DELETE FROM chunks WHERE id = ?", (chunk_id,))


def get_file(db, path):
    return db.execute("SELECT * FROM files WHERE path = ?", (path,)).fetchone()


def set_file(db, path, repo, sha256, mtime_ns, size):
    db.execute(
        "INSERT OR REPLACE INTO files(path, repo, sha256, mtime_ns, size,"
        " indexed_at) VALUES (?, ?, ?, ?, ?, ?)",
        (path, repo, sha256, mtime_ns, size, _now()))


def delete_file(db, path):
    ids = [r[0] for r in db.execute(
        "SELECT id FROM chunks WHERE kind = 'code' AND file = ?", (path,))]
    delete_chunks(db, ids)
    db.execute("DELETE FROM imports WHERE file = ?", (path,))
    db.execute("DELETE FROM files WHERE path = ?", (path,))
    return len(ids)


def set_imports(db, path, imports):
    db.execute("DELETE FROM imports WHERE file = ?", (path,))
    db.executemany("INSERT INTO imports(file, local, module, name)"
                   " VALUES (?, ?, ?, ?)",
                   [(path, i["local"], i["module"], i["name"]) for i in imports])


def get_import(db, path, local):
    return db.execute("SELECT * FROM imports WHERE file = ? AND local = ?",
                      (path, local)).fetchone()


def tracked_files(db, repo=None, under=None):
    """Indexed file paths: all, one repo's, or those inside folder `under`."""
    if repo is not None:
        paths = [r[0] for r in db.execute(
            "SELECT path FROM files WHERE repo = ?", (repo,))]
    else:
        paths = [r[0] for r in db.execute("SELECT path FROM files")]
    if under is not None:
        paths = [p for p in paths if _inside(p, str(under))]
    return paths


def _insert_indexes(db, item_id, repo, vector, name_text, body):
    db.execute("INSERT INTO vec_chunks(rowid, embedding, repo) VALUES (?, ?, ?)",
               (item_id, sqlite_vec.serialize_float32(list(map(float, vector))),
                repo))
    db.execute("INSERT INTO chunks_fts(rowid, name, code) VALUES (?, ?, ?)",
               (item_id, name_text, body))


def insert_chunk(db, chunk, repo, name_text, vector):
    cur = db.execute(
        "INSERT INTO chunks(kind, repo, file, name, qualname, start_line,"
        " end_line, code, code_hash) VALUES ('code', ?, ?, ?, ?, ?, ?, ?, ?)",
        (repo, chunk["file"], chunk["name"], chunk["qualname"],
         chunk["start_line"], chunk["end_line"], chunk["code"],
         chunk["code_hash"]))
    chunk_id = cur.lastrowid
    _insert_indexes(db, chunk_id, repo, vector, name_text, chunk["code"])
    db.executemany(
        "INSERT INTO calls(caller_id, name, obj, kind, line_offset)"
        " VALUES (?, ?, ?, ?, ?)",
        [(chunk_id, c["name"], c["obj"], c["kind"], c["line_offset"])
         for c in chunk.get("calls", [])])
    return chunk_id


# ---- notes -----------------------------------------------------------------

def split_tags(tags):
    """'a, b' or ['a', ' b'] -> ['a', 'b']"""
    if not tags:
        return []
    if isinstance(tags, str):
        tags = tags.split(",")
    return [t.strip() for t in tags if t.strip()]


def insert_note(db, text, tags=None, created_at=None):
    """Store a note and index it. Imports lazily: embedding needs the model."""
    from .embed import embed_documents
    from .text import expansions, split_words

    tags = split_tags(tags)
    cur = db.execute(
        "INSERT INTO chunks(kind, repo, code, tags, created_at)"
        " VALUES ('note', ?, ?, ?, ?)",
        (NOTE_REPO, text, ",".join(tags), created_at or _now()))
    tag_words = " ".join(tags)
    tag_text = " ".join(tags + split_words(tag_words) + expansions(tag_words))
    # the embedding sees all expansions (they help vector search)
    exp = expansions(text + " " + tag_words)
    vector = embed_documents([f"note: {', '.join(tags)}\n"
                              + (f"# {', '.join(exp)}\n" if exp else "") + text])[0]
    _insert_indexes(db, cur.lastrowid, NOTE_REPO, vector, tag_text, text)
    return cur.lastrowid


# ---- misc ------------------------------------------------------------------

def set_meta(db, key, value):
    db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
               (key, value))


def get_meta(db, key, default=None):
    row = db.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def count_chunks(db, kind="code", repo=None):
    if repo is None:
        return db.execute("SELECT COUNT(*) FROM chunks WHERE kind = ?",
                          (kind,)).fetchone()[0]
    return db.execute("SELECT COUNT(*) FROM chunks WHERE kind = ? AND repo = ?",
                      (kind, repo)).fetchone()[0]
