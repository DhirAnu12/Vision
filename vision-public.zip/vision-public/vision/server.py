"""MCP server (stdio) exposing Vision to AI agents: `search` and `remember`.

Run with `vision serve`. In stdio mode stdout carries the protocol itself,
so nothing in here may print() to stdout - use stderr for diagnostics.
"""
import os
import sys
import threading
from contextlib import closing

from mcp.server.mcpserver import MCPServer

from . import db as vdb
from .embed import get_model
from .search import format_results, search as run_search

server = MCPServer(
    "vision",
    instructions=(
        "Vision is a local search index over this user's code plus notes "
        "previously saved with `remember`. Use `search` before reading files "
        "to find relevant functions or past decisions. Use `remember` to save "
        "decisions and the reasons behind them so future sessions can find them."
    ),
)


# Tools run in a worker thread and a sqlite connection belongs to the thread
# that opened it, so each call opens (and closes) its own connection.
def _connect():
    return closing(vdb.connect())


@server.tool(structured_output=False)
def search(query: str, k: int = 5, repo: str | None = None,
           graph: bool = False) -> str:
    """Search indexed code and saved notes by meaning and by keyword.

    Use natural language ("where is speech to text set up") or identifiers
    ("_build_stt"). Returns up to k results: functions with repo, file path,
    line range, source and a trust verdict (STRONG/REBUILT = current,
    STALE = may be outdated, DEAD = no longer exists), and notes with tags.
    repo: only search this repo (by name, as shown in results); notes are
      always included. Omit to search all repos.
    graph: also list what each function calls and what calls it - useful
      before changing a function, to see what depends on it.
    """
    k = max(1, min(k, 50))
    with _connect() as db:
        if vdb.count_chunks(db, "code") + vdb.count_chunks(db, "note") == 0:
            return ("The Vision index is empty. Ask the user to run "
                    "`vision index <repo>`.")
        try:
            results = run_search(db, query, k=k, repo=repo, graph_info=graph)
        except ValueError as e:  # e.g. unknown repo; message lists known ones
            return str(e)
        return format_results(results)


@server.tool(structured_output=False)
def remember(note: str, tags: list[str] | None = None) -> str:
    """Save a note to long-term memory so it can be found by `search` later.

    Good notes record decisions and their reasons ("We use the local STT
    engine because the cloud one was too slow for live audio"), gotchas,
    and conventions.
    Write the note so it makes sense on its own, months from now.
    tags: optional short labels, e.g. ["decision", "stt"].
    """
    note = note.strip()
    if not note:
        return "Nothing saved: the note is empty."
    with _connect() as db:
        note_id = vdb.insert_note(db, note, tags)
        db.commit()
    return f"Saved note #{note_id}."


def main():
    # Load the model in the background so the first search is fast;
    # get_model() has a lock, so a search arriving early just waits.
    threading.Thread(target=get_model, daemon=True).start()
    path = os.path.abspath(vdb.default_db_path())
    print(f"vision MCP server using {path}", file=sys.stderr)
    server.run("stdio")
