"""Command line: `vision index|watch <repo>`, `vision repos|remove`,
`vision search "<query>"`, `vision remember "<note>"`, `vision serve`."""
import argparse
import os
import sys
from pathlib import Path

from . import db as vdb


def _repo_arg(repo):
    repo = Path(repo)
    if not repo.is_dir():
        sys.exit(f"not a directory: {repo}")
    return repo


def cmd_index(args):
    from .indexer import index_repo
    repo = _repo_arg(args.repo)
    db = vdb.connect(args.db)
    try:
        s = index_repo(repo, db, name=args.name, full=args.full)
    except ValueError as e:
        sys.exit(str(e))
    print(f"[{s['repo']}] {s['files']} files: {s['changed']} new/changed,"
          f" {s['deleted']} deleted (+{s['added']} -{s['removed']} functions);"
          f" {s['chunks']} functions in {args.db or vdb.default_db_path()}")


def cmd_search(args):
    from .search import format_results, search
    db = vdb.connect(args.db)
    if vdb.count_chunks(db, "code") + vdb.count_chunks(db, "note") == 0:
        sys.exit("index is empty - run `vision index <repo>` first")
    try:
        results = search(db, args.query, k=args.k, mode=args.mode,
                         use_prefix=not args.no_prefix,
                         refresh=not args.no_refresh, repo=args.repo,
                         graph_info=args.graph)
    except ValueError as e:
        sys.exit(str(e))
    print(format_results(results, show_text=args.code), end="")


def cmd_watch(args):
    from .watch import watch
    repo = _repo_arg(args.repo)
    print("Ctrl+C to stop")
    try:
        watch(repo, args.db, on_log=lambda line: print(line, flush=True),
              name=args.name)
    except ValueError as e:
        sys.exit(str(e))


def cmd_repos(args):
    db = vdb.connect(args.db)
    repos = vdb.get_repos(db)
    if not repos:
        print("no repos indexed")
    for r in repos:
        n = vdb.count_chunks(db, repo=r["name"])
        print(f"{r['name']:<20} {n:>6} functions  {r['root']}")
    print(f"{vdb.count_chunks(db, 'note')} notes (shared by all repos)")


def cmd_remove(args):
    db = vdb.connect(args.db)
    if args.name not in {r["name"] for r in vdb.get_repos(db)}:
        sys.exit(f"no repo named {args.name!r}")
    n = vdb.remove_repo(db, args.name)
    db.commit()
    print(f"removed repo {args.name!r} ({n} functions); notes kept")


def cmd_eval(args):
    from . import evaluate
    db = vdb.connect(args.db)
    bench = evaluate.load(args.benchmark)
    notes = ""
    if args.notes:
        with open(args.notes, encoding="utf-8") as f:
            notes = f.read()
    try:
        results = evaluate.run(db, bench)
    except ValueError as e:
        sys.exit(str(e))
    text = evaluate.report(bench, results, notes)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"wrote {args.out}")
    for c in results:
        s = evaluate.summarize(results[c]["rows"])
        print(f"{c:<20} hit@5 {s['hit']:.2f}  recall@5 {s['recall']:.2f}"
              f"  MRR {s['mrr']:.2f}")


def cmd_remember(args):
    db = vdb.connect(args.db)
    note_id = vdb.insert_note(db, args.note, args.tags)
    db.commit()
    print(f"saved note #{note_id}")


def cmd_serve(args):
    if args.db:
        os.environ["VISION_DB"] = args.db
    from .server import main as serve
    serve()


def main(argv=None):
    # Windows consoles default to cp1252 and crash on characters like '→'.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    # Silence a harmless HuggingFace tokenizers fork warning.
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    p = argparse.ArgumentParser(prog="vision",
                                description="Local code search for AI agents.")
    p.add_argument("--db", help="database file (default: $VISION_DB or ./vision.db)")
    sub = p.add_subparsers(dest="command", required=True)

    pi = sub.add_parser("index", help="index a repository (only changed files)")
    pi.add_argument("repo")
    pi.add_argument("--full", action="store_true",
                    help="rebuild this repo's code from scratch (notes are kept)")
    pi.add_argument("--name", help="repo name (default: folder name)")
    pi.set_defaults(func=cmd_index)

    pw = sub.add_parser("watch", help="keep a repository indexed as files change")
    pw.add_argument("repo")
    pw.add_argument("--name", help="repo name (default: folder name)")
    pw.set_defaults(func=cmd_watch)

    pl = sub.add_parser("repos", help="list indexed repositories")
    pl.set_defaults(func=cmd_repos)

    pd = sub.add_parser("remove", help="remove a repository from the index")
    pd.add_argument("name")
    pd.set_defaults(func=cmd_remove)

    ps = sub.add_parser("search", help="search the index")
    ps.add_argument("query")
    ps.add_argument("-k", type=int, default=5, help="number of results")
    ps.add_argument("--mode", choices=["hybrid", "vector", "keyword"],
                    default="hybrid")
    ps.add_argument("--no-prefix", action="store_true",
                    help="don't add the bge query prefix")
    ps.add_argument("--code", action="store_true", help="print code / note text too")
    ps.add_argument("--no-refresh", action="store_true",
                    help="don't re-index changed files (shows STALE/DEAD as-is)")
    ps.add_argument("--repo", help="only search this repo (notes always included)")
    ps.add_argument("--graph", action="store_true",
                    help="show what each result calls and is called by")
    ps.set_defaults(func=cmd_search)

    pe = sub.add_parser("eval", help="measure search quality on labelled queries")
    pe.add_argument("benchmark", help="benchmark JSON (see README: Evaluation)")
    pe.add_argument("--out", help="write the markdown report here")
    pe.add_argument("--notes", help="markdown file with notes to put in the report")
    pe.set_defaults(func=cmd_eval)

    pr = sub.add_parser("remember", help="save a searchable note")
    pr.add_argument("note")
    pr.add_argument("--tags", default="", help="comma-separated, e.g. decision,stt")
    pr.set_defaults(func=cmd_remember)

    pv = sub.add_parser("serve", help="run the MCP server on stdio")
    pv.set_defaults(func=cmd_serve)

    args = p.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
