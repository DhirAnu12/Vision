"""Call graph: which indexed functions a function calls, and which call it.

Python is dynamic, so from syntax alone `x.run()` could be any `run`. Call
sites are stored exactly as written (see indexer._call_site) and resolved
here at query time with a few rules, best guess first. Resolving at query
time means re-indexing one file never leaves stale links in another.
"""
import os
from pathlib import Path

from .db import get_import

MAX_CANDIDATES = 3   # more matches than this = too ambiguous to be useful
MAX_SHOWN = 10       # per direction, per result

_COLS = "id, qualname, name, file, start_line"


def _prefixes(qualname):
    """'A.run.inner' -> ['A.run.inner', 'A.run', 'A']: the scopes a call
    inside it can see (nested functions, sibling methods)."""
    parts = qualname.split(".")
    return [".".join(parts[:i]) for i in range(len(parts), 0, -1)]


def _like_escape(s):
    return s.replace("!", "!!").replace("%", "!%").replace("_", "!_")


def _module_files(importer, module):
    """SQL condition matching the file(s) a module name refers to.
    '.search' (relative) -> next to the importer: <dir>/search.py exactly;
    'vision.search' -> any file ending in /vision/search.py (or __init__.py)."""
    if module.startswith("."):
        dots = len(module) - len(module.lstrip("."))
        base = Path(importer).parent
        for _ in range(dots - 1):
            base = base.parent
        rest = module.lstrip(".")
        target = base.joinpath(*rest.split(".")) if rest else base
        paths = [f"{target}.py", str(target / "__init__.py")]
        return "file IN (?, ?)", paths
    rel = os.path.join(*module.split("."))
    pats = [f"%{os.sep}{_like_escape(rel)}.py",
            f"%{os.sep}{_like_escape(os.path.join(rel, '__init__'))}.py"]
    return "(file LIKE ? ESCAPE '!' OR file LIKE ? ESCAPE '!')", pats


def _import_tiers(db, file, local, attr=None):
    """Tiers from the caller file's imports of `local`.
    attr=None: a call `local()`; attr='f': a call `local.f()`."""
    imp = get_import(db, file, local)
    if imp is None:
        return []
    module, name = imp["module"], imp["name"]
    if attr is None:
        if name is None:
            return []  # calling a module itself makes no sense
        where, params = _module_files(file, module)
        return [(f"(qualname = ? OR qualname = ?) AND {where}",
                 [name, f"{name}.__init__", *params])]
    if name is None:  # import pkg.mod as m; m.f()
        where, params = _module_files(file, module)
        return [(f"qualname = ? AND {where}", [attr, *params])]
    # from pkg import thing; thing.f(): thing is a submodule or a class
    sub = module + ("" if module.endswith(".") else ".") + name
    w1, p1 = _module_files(file, sub)
    w2, p2 = _module_files(file, module)
    return [(f"(qualname = ? AND {w1}) OR (qualname = ? AND {w2})",
             [attr, *p1, f"{name}.{attr}", *p2])]


def _tiers(db, call, caller):
    """SQL conditions to try in order for one call site. Each is
    (where-clause, params), always within the caller's repo."""
    name, kind, obj = call["name"], call["kind"], call["obj"]
    file = caller["file"]
    scoped = [f"{p}.{name}" for p in _prefixes(caller["qualname"])]
    marks = ",".join("?" * len(scoped))

    if kind == "self":  # self.name(): a method, ideally of the same class
        return [
            (f"file = ? AND qualname IN ({marks})", [file, *scoped]),
            ("file = ? AND name = ? AND qualname != name", [file, name]),
            ("name = ? AND qualname != name", [name]),  # e.g. a base class
        ]
    if kind == "name":  # name(): nested/local function, class, or import
        local = [
            (f"file = ? AND (qualname IN ({marks}) OR qualname = ?)",
             [file, *scoped, name]),
            ("file = ? AND qualname = ?", [file, f"{name}.__init__"]),
        ]
        if get_import(db, file, name):
            # imported: it's whatever the import says - if that isn't in
            # the repo (`from os.path import join`), it's external
            return local + _import_tiers(db, file, name)
        return local + [("qualname = ? OR qualname = ?",
                         [name, f"{name}.__init__"])]
    # obj.name()
    if obj and get_import(db, file, obj):
        # obj is an imported module/class: follow the import only. If it
        # leads outside the repo (`subprocess.run`), it's external.
        return _import_tiers(db, file, obj, attr=name)
    tiers = []
    if obj:  # looks like a module (file obj.py) or a class we know?
        tiers.append((
            "(qualname = ? AND (file LIKE ? ESCAPE '!')) OR qualname = ?",
            [name, f"%{os.sep}{_like_escape(obj)}.py", f"{obj}.{name}"]))
    if name not in BUILTIN_METHODS:
        # Last resort: any method with that name. We don't know obj's type,
        # so this is a guess (shown with '?').
        tiers.append(("name = ? AND qualname != name", [name], GUESS))
    return tiers


GUESS = "guess"
# Method names of dict/list/str/file etc. `x.get()` is far more likely a
# dict than a repo function that happens to be called `get`.
BUILTIN_METHODS = {
    "get", "items", "keys", "values", "update", "pop", "popitem", "setdefault",
    "append", "extend", "insert", "remove", "clear", "copy", "sort", "reverse",
    "index", "count", "add", "discard", "union", "intersection",
    "split", "rsplit", "join", "strip", "lstrip", "rstrip", "replace",
    "format", "lower", "upper", "startswith", "endswith", "encode", "decode",
    "find", "splitlines", "read", "write", "readline", "readlines", "close",
    "flush", "seek", "tolist", "astype", "reshape", "mean", "sum",
}


def resolve(db, call, caller):
    """Indexed functions this call most likely refers to (maybe several),
    as dicts with "guess": True when matched by name alone."""
    for where, params, *flag in _tiers(db, call, caller):
        rows = db.execute(
            f"SELECT {_COLS} FROM chunks WHERE kind = 'code' AND repo = ?"
            f" AND ({where})", [caller["repo"], *params]).fetchall()
        if rows:
            if len(rows) > MAX_CANDIDATES:
                return []
            return [{**dict(r), "guess": GUESS in flag} for r in rows]
    return []


def callees(db, chunk_id):
    """[{id, qualname, file, start_line, line, guess}] that chunk_id calls.
    `line` is where the call happens (in the caller). Sure links first."""
    caller = db.execute("SELECT * FROM chunks WHERE id = ?", (chunk_id,)).fetchone()
    out, seen = [], set()
    for call in db.execute("SELECT * FROM calls WHERE caller_id = ?"
                           " ORDER BY line_offset", (chunk_id,)):
        for t in resolve(db, call, caller):
            if t["id"] not in seen and t["id"] != chunk_id:
                seen.add(t["id"])
                out.append({**t, "line": caller["start_line"] + call["line_offset"]})
    return _sure_first(out)[:MAX_SHOWN]


def _sure_first(entries):
    return sorted(entries, key=lambda e: e["guess"])  # stable: keeps order


def callers(db, chunk_id):
    """[{id, qualname, file, start_line, line}] of functions that call
    chunk_id. `line` is the call site inside the caller."""
    target = db.execute("SELECT * FROM chunks WHERE id = ?", (chunk_id,)).fetchone()
    names = [target["name"]]
    if target["name"] == "__init__" and "." in target["qualname"]:
        names.append(target["qualname"].split(".")[-2])  # Foo() calls Foo.__init__
    out, seen = [], set()
    rows = db.execute(
        f"SELECT calls.*, {', '.join('c.' + c for c in ('repo', 'file', 'qualname', 'start_line'))}"
        f" FROM calls JOIN chunks c ON c.id = calls.caller_id"
        f" WHERE calls.name IN ({','.join('?' * len(names))}) AND c.repo = ?"
        f" ORDER BY c.file, c.start_line", [*names, target["repo"]]).fetchall()
    for row in rows:
        if row["caller_id"] in seen or row["caller_id"] == chunk_id:
            continue
        match = [t for t in resolve(db, row, row) if t["id"] == chunk_id]
        if match:
            seen.add(row["caller_id"])
            out.append({"id": row["caller_id"], "qualname": row["qualname"],
                        "file": row["file"], "start_line": row["start_line"],
                        "line": row["start_line"] + row["line_offset"],
                        "guess": match[0]["guess"]})
    return _sure_first(out)[:MAX_SHOWN]


def short_path(file, root):
    try:
        return Path(file).relative_to(root).as_posix()
    except (ValueError, TypeError):
        return file
