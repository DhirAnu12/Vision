"""Search: vector (meaning), keyword (exact words, FTS5/BM25), and hybrid
(both, merged with reciprocal rank fusion) - plus a trust verdict per hit."""
from dataclasses import dataclass, field

import sqlite_vec

from . import graph
from .db import NOTE_REPO, get_repos, split_tags
from .embed import embed_query
from .indexer import current_qualnames, file_status, refresh_file
from .text import fts_query

RRF_K = 60        # standard RRF constant; dampens the gap between rank 1 and 2
CANDIDATES = 50   # how many results each method contributes before fusing
# BM25 column weights for (name, code): a hit in the function name matters
# more than one somewhere in its body.
BM25_WEIGHTS = (5.0, 1.0)
MAX_REFRESH_ROUNDS = 2  # re-runs after re-indexing; bounded so a file being
                        # saved over and over can't keep us looping

# Verdicts for code results (notes have none):
STRONG = "STRONG"    # file unchanged since indexing: the code shown is current
STALE = "STALE"      # file changed since indexing: the code shown may be outdated
DEAD = "DEAD"        # the function no longer exists
REBUILT = "REBUILT"  # file had changed; re-indexed just now, the code is current


@dataclass
class Result:
    kind: str          # 'code' or 'note'
    id: int
    name: str          # qualname for code, 'note #3' for notes
    text: str          # function source or note text
    score: float
    ranks: dict = field(default_factory=dict)  # e.g. {"vector": 4, "keyword": 1}
    file: str | None = None        # code only
    start_line: int | None = None
    end_line: int | None = None
    tags: list = field(default_factory=list)   # notes only
    created_at: str | None = None
    # identical copies elsewhere: [{"id": .., "file": .., "start_line": ..}]
    also_in: list = field(default_factory=list)
    verdict: str | None = None     # code only, see above
    repo: str | None = None        # code only
    # with graph=True: [{"id", "qualname", "file", "start_line", "line"}]
    callers: list | None = None
    callees: list | None = None


def vector_search(db, query, n=CANDIDATES, use_prefix=True, repo=None):
    """Chunk ids ranked by embedding similarity (best first).
    repo: only that repo's code (plus notes, which are global). The filter
    runs inside the KNN search, so a small repo isn't crowded out."""
    q = sqlite_vec.serialize_float32(embed_query(query, use_prefix=use_prefix).tolist())
    if repo is None:
        rows = db.execute(
            "SELECT rowid FROM vec_chunks WHERE embedding MATCH ? AND k = ?"
            " ORDER BY distance", (q, n)).fetchall()
    else:
        rows = db.execute(
            "SELECT rowid FROM vec_chunks WHERE embedding MATCH ? AND k = ?"
            " AND repo IN (?, ?) ORDER BY distance",
            (q, n, repo, NOTE_REPO)).fetchall()
    return [r[0] for r in rows]


def keyword_search(db, query, n=CANDIDATES, repo=None):
    """Chunk ids ranked by BM25 over name and code."""
    match = fts_query(query)
    if match is None:
        return []
    w = BM25_WEIGHTS
    where, params = "", [match]
    if repo is not None:
        where, params = " AND c.repo IN (?, ?)", [match, repo, NOTE_REPO]
    rows = db.execute(
        f"SELECT f.rowid FROM chunks_fts f JOIN chunks c ON c.id = f.rowid"
        f" WHERE chunks_fts MATCH ?{where}"
        f" ORDER BY bm25(chunks_fts, {w[0]}, {w[1]}) LIMIT ?",
        (*params, n)).fetchall()
    return [r[0] for r in rows]


def rrf(rankings, k=RRF_K, weights=None):
    """Fuse ranked id lists: {"vector": [7, 3], "keyword": [3, 9]}.
    weights: optional {source: w}; a source's ranks count w times (default 1).

    Returns [(id, score, {source: rank})] best first.
    """
    weights = weights or {}
    scores, ranks = {}, {}
    for source, ids in rankings.items():
        w = weights.get(source, 1.0)
        for rank, chunk_id in enumerate(ids, start=1):
            scores[chunk_id] = scores.get(chunk_id, 0.0) + w / (k + rank)
            ranks.setdefault(chunk_id, {})[source] = rank
    ordered = sorted(scores, key=lambda i: scores[i], reverse=True)
    return [(i, scores[i], ranks[i]) for i in ordered]


def search(db, query, k=5, mode="hybrid", use_prefix=True, refresh=True,
           repo=None, graph_info=False, keyword_weight=1.0,
           keyword_candidates=CANDIDATES):
    """Ranked results with a trust verdict on each code hit.

    mode: 'hybrid' (default), 'vector' or 'keyword'.
    refresh: re-index files that changed since indexing and search again,
      so hits come back REBUILT instead of STALE. Hits whose function was
      deleted are appended at the end with verdict DEAD (beyond k), so the
      caller learns that something it may remember is gone.
    repo: search only this repo's code (notes are always included).
    graph_info: also fill in callers/callees of each live code hit.
    keyword_weight / keyword_candidates: how much the keyword list counts in
      hybrid fusion, and how many keyword hits get a vote (for `vision eval` experiments).
    """
    tuning = {"keyword_weight": keyword_weight,
              "keyword_candidates": keyword_candidates}
    if repo is not None and repo not in {r["name"] for r in get_repos(db)}:
        known = ", ".join(r["name"] for r in get_repos(db)) or "none"
        raise ValueError(f"unknown repo {repo!r} (indexed repos: {known})")
    rebuilt, dead = set(), []
    for _round in range(MAX_REFRESH_ROUNDS + 1):
        results = _rank(db, query, k, mode, use_prefix, repo, **tuning)
        status = {f: file_status(db, f) for f in _files(results)}
        outdated = {f for f, s in status.items() if s != "fresh"} - rebuilt
        if not refresh or not outdated or _round == MAX_REFRESH_ROUNDS:
            break
        for f in outdated:
            refresh_file(db, f)
            rebuilt.add(f)
            exists = current_qualnames(f)
            dead += [r for r in results
                     if r.kind == "code" and r.file == f and r.name not in exists]
        db.commit()

    for r in results:
        if r.kind != "code":
            continue
        s = status[r.file]
        if r.file in rebuilt:
            r.verdict = REBUILT
        elif s == "fresh":
            r.verdict = STRONG
        elif s == "changed" and r.name in current_qualnames(r.file):
            r.verdict = STALE
        else:  # file deleted, or the function was removed from it
            r.verdict = DEAD
    for r in dead:
        r.verdict = DEAD
    if graph_info:
        roots = {x["name"]: x["root"] for x in get_repos(db)}
        for r in results:
            if r.kind == "code" and r.verdict != DEAD:
                r.callers = graph.callers(db, r.id)
                r.callees = graph.callees(db, r.id)
                for g in r.callers + r.callees:
                    g["path"] = graph.short_path(g["file"], roots.get(r.repo))
    return results + dead


def _files(results):
    files = set()
    for r in results:
        if r.kind == "code":
            files.add(r.file)
            files.update(c["file"] for c in r.also_in)
    return files


def _rank(db, query, k, mode, use_prefix, repo, keyword_weight=1.0,
          keyword_candidates=CANDIDATES):
    rankings = {}
    if mode in ("hybrid", "vector"):
        rankings["vector"] = vector_search(db, query, use_prefix=use_prefix,
                                           repo=repo)
    if mode in ("hybrid", "keyword"):
        rankings["keyword"] = keyword_search(db, query, n=keyword_candidates,
                                             repo=repo)
    if not rankings:
        raise ValueError(f"unknown search mode: {mode!r}")

    results, seen = [], set()
    for item_id, score, ranks in rrf(rankings, weights={"keyword": keyword_weight}):
        if item_id in seen:
            continue  # an exact copy of a result we already have
        r = _load_result(db, item_id, score, ranks)
        if r.kind == "code":
            r.also_in = _copies(db, item_id, repo)
            seen.update(c["id"] for c in r.also_in)
        results.append(r)
        if len(results) == k:
            break
    return results


def _copies(db, chunk_id, repo=None):
    """Other chunks with the same qualname and identical code, e.g. the same
    function in a copied project. Shown once, so they don't use up slots.
    With a repo filter, only copies inside that repo count."""
    rows = db.execute(
        "SELECT c.id, c.repo, c.file, c.start_line FROM chunks c"
        " JOIN chunks me ON me.id = ?"
        " WHERE c.kind = 'code' AND c.qualname = me.qualname"
        " AND c.code_hash = me.code_hash AND c.id != me.id"
        " AND (? IS NULL OR c.repo = ?) ORDER BY c.repo, c.file",
        (chunk_id, repo, repo)).fetchall()
    return [dict(row) for row in rows]


def _load_result(db, item_id, score, ranks):
    row = db.execute("SELECT * FROM chunks WHERE id = ?", (item_id,)).fetchone()
    if row["kind"] == "note":
        return Result("note", item_id, f"note #{item_id}", row["code"], score,
                      ranks, tags=split_tags(row["tags"]),
                      created_at=row["created_at"])
    return Result("code", item_id, row["qualname"], row["code"], score, ranks,
                  file=row["file"], start_line=row["start_line"],
                  end_line=row["end_line"], repo=row["repo"])


MAX_CODE_LINES = 40

_WARNINGS = {
    STALE: "file changed since indexing - this code may be out of date",
    DEAD: "this function no longer exists",
}


def _graph_list(entries, line_key):
    """callees point at the definition, callers at the call site."""
    if not entries:
        return "(none found)"
    return ", ".join(f"{g['qualname']}{'?' if g['guess'] else ''}"
                     f" ({g['path']}:{g[line_key]})" for g in entries)


def format_results(results, show_text=True, max_lines=MAX_CODE_LINES):
    """Plain-text rendering for agents (MCP) and the CLI. Code is capped at
    max_lines so a huge function can't flood an agent's context."""
    live = [r for r in results if r.verdict != DEAD]
    dead = [r for r in results if r.verdict == DEAD]
    if not results:
        return "no results\n"
    out = []
    for n, r in enumerate(live, start=1):
        found = ", ".join(f"{src} #{rank}" for src, rank in r.ranks.items())
        if r.kind == "note":
            tags = f"  tags: {', '.join(r.tags)}" if r.tags else ""
            out.append(f"{n}. [note #{r.id}] {r.created_at}{tags}  [{found}]")
            lines = r.text.splitlines()
        else:
            out.append(f"{n}. [{r.verdict}] {r.name}  ({r.repo}) {r.file}:"
                       f"{r.start_line}-{r.end_line}  [{found}]")
            if r.verdict in _WARNINGS:
                out.append(f"   ! {_WARNINGS[r.verdict]}")
            for c in r.also_in:
                out.append(f"   also in: ({c['repo']}) {c['file']}:{c['start_line']}"
                           " (identical)")
            if r.callees is not None:
                out.append("   calls: " + _graph_list(r.callees, "start_line"))
            if r.callers is not None:
                out.append("   called by: " + _graph_list(r.callers, "line"))
            lines = r.text.splitlines()
            if len(lines) > max_lines:
                hidden = len(lines) - max_lines
                lines = lines[:max_lines] + [f"... ({hidden} more lines)"]
        if show_text:
            out.extend("    " + line for line in lines)
            out.append("")
    if any(g["guess"] for r in live for g in (r.callers or []) + (r.callees or [])):
        out.append("(? = call matched by method name only; the link may be wrong)")
    if dead:
        out.append("No longer exist (matched the old index, deleted since):")
        out.extend(f"  [DEAD] {r.name}  ({r.repo}) {r.file}:{r.start_line}"
                   for r in dead)
    return "\n".join(out).rstrip() + "\n"
