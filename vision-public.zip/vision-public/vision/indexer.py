"""Find Python files, split them into function chunks, embed and store them.

Indexing is incremental: each file's sha256 is stored, unchanged files are
skipped, and inside a changed file only new/changed functions are embedded.
"""
import hashlib
from pathlib import Path

import tree_sitter_python as tspython
from tree_sitter import Language, Parser

from . import db as vdb
from .embed import embed_documents
from .text import expansions, split_words

SKIP = {"venv", ".venv", "env", ".git", "__pycache__", "node_modules",
        "site-packages"}

_parser = Parser(Language(tspython.language()))


def norm_path(path):
    """One spelling per file (absolute, resolved), so paths from rglob,
    watchdog and the database always compare equal."""
    return str(Path(path).resolve())


def sha256(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def is_indexable(path, root):
    """A .py file inside root that isn't in a venv/hidden/cache folder.
    Only parts *inside* the repo count, so a repo that itself lives under
    e.g. "C:/.../.hidden/" isn't skipped entirely."""
    path, root = Path(path), Path(root)
    if path.suffix != ".py":
        return False
    try:
        parts = path.relative_to(root).parts
    except ValueError:
        return False
    return not any(p in SKIP or p.startswith(".") for p in parts)


def find_files(repo_path):
    root = Path(repo_path)
    return [p for p in sorted(root.rglob("*.py")) if is_indexable(p, root)]


def get_chunks(file_path, source=None):
    """One chunk per function or method, including nested ones.

    qualname shows where it lives: 'VoiceAgent.__init__' for a method,
    'register.summarize' for a function defined inside `register`.
    """
    return parse_file(file_path, source)[0]


def parse_file(file_path, source=None):
    """Parse once, return (chunks, imports)."""
    if source is None:
        source = Path(file_path).read_bytes()
    tree = _parser.parse(source)
    chunks, imports = [], []

    def walk(node, scope, current):
        if node.type in ("import_statement", "import_from_statement"):
            imports.extend(_imports(node))
        elif node.type == "class_definition":
            name = node.child_by_field_name("name").text.decode()
            scope = scope + [name]
        elif node.type == "function_definition":
            name = node.child_by_field_name("name").text.decode()
            # Decorators (@mcp.tool(), @property) live on the parent node.
            outer = node.parent if node.parent.type == "decorated_definition" else node
            # Normalise Windows \r\n so copies that differ only in line
            # endings count as identical.
            code = outer.text.decode("utf-8", errors="ignore").replace("\r\n", "\n")
            current = {
                "file": str(file_path),
                "name": name,
                "qualname": ".".join(scope + [name]),
                "start_line": outer.start_point[0] + 1,
                "end_line": outer.end_point[0] + 1,
                "code": code,
                "code_hash": sha256(code),
                "calls": [],
            }
            chunks.append(current)
            scope = scope + [name]
        elif node.type == "call" and current is not None:
            call = _call_site(node, current["start_line"])
            if call and not any((c["name"], c["obj"], c["kind"]) ==
                                (call["name"], call["obj"], call["kind"])
                                for c in current["calls"]):
                current["calls"].append(call)  # first occurrence only
        for child in node.children:
            walk(child, scope, current)

    walk(tree.root_node, [], None)
    return chunks, imports


def _imports(node):
    """Names bound by one import statement:
    import a.b        -> local 'a', module 'a'      (name None)
    import a.b as c   -> local 'c', module 'a.b'    (name None)
    from .m import f  -> local 'f', module '.m',    name 'f'
    from m import f as g -> local 'g', module 'm',  name 'f'
    """
    out = []
    if node.type == "import_statement":
        for child in node.named_children:
            if child.type == "aliased_import":
                module = child.child_by_field_name("name").text.decode()
                local = child.child_by_field_name("alias").text.decode()
            elif child.type == "dotted_name":
                module = local = child.text.decode().split(".")[0]
            else:
                continue
            out.append({"local": local, "module": module, "name": None})
    else:
        module = node.child_by_field_name("module_name").text.decode()
        for child in node.children_by_field_name("name"):
            if child.type == "aliased_import":
                name = child.child_by_field_name("name").text.decode()
                local = child.child_by_field_name("alias").text.decode()
            else:
                name = local = child.text.decode()
            out.append({"local": local, "module": module, "name": name})
    return out


def _call_site(node, func_start_line):
    """Describe a call as written: foo() / self.foo() / x.foo().

    Returns {"name", "obj", "kind", "line_offset"} or None for calls we
    can't name (e.g. `handlers[i]()`, `get_fn()()`).
    """
    fn = node.child_by_field_name("function")
    obj = None
    if fn.type == "identifier":
        kind, name = "name", fn.text.decode()
    elif fn.type == "attribute":
        name = fn.child_by_field_name("attribute").text.decode()
        target = fn.child_by_field_name("object")
        if target.type == "identifier" and target.text in (b"self", b"cls"):
            kind = "self"
        else:
            kind = "attr"
            # remember the receiver only when it's a plain name: `drop.register`
            if target.type == "identifier":
                obj = target.text.decode()
    else:
        return None
    return {"name": name, "obj": obj, "kind": kind,
            "line_offset": node.start_point[0] + 1 - func_start_line}


def name_text(chunk):
    """Keyword text for the high-weight name column: the qualname, its split
    words ('VoiceAgent' -> 'voice agent') and their expansions
    ('_build_stt' -> '... speech to text'). The name says what a function
    *is about*, so an abbreviation here counts more than one in the body."""
    q = chunk["qualname"]
    return " ".join([q] + split_words(q) + expansions(q))


def embedding_text(chunk):
    """What the model embeds. Unlike the keyword index, this includes
    expansions for abbreviations anywhere in the code: the eval showed they
    help vector search ('stt provider setup' -> _build_stt)."""
    text = f"{Path(chunk['file']).name} {chunk['qualname']}\n"
    exp = expansions(chunk["code"])
    if exp:
        text += "# " + ", ".join(exp) + "\n"
    return text + chunk["code"]


# ---- freshness --------------------------------------------------------------

def file_status(db, path):
    """'fresh', 'changed', 'deleted' or 'untracked' compared to the index.

    Like git: if size and mtime match what we stored, trust it without
    reading the file. Otherwise hash it - an editor may have saved it
    without changing anything, which still counts as fresh.
    """
    path = norm_path(path)
    rec = vdb.get_file(db, path)
    p = Path(path)
    if not p.is_file():
        return "deleted" if rec else "untracked"
    if rec is None:
        return "untracked"
    st = p.stat()
    if st.st_mtime_ns == rec["mtime_ns"] and st.st_size == rec["size"]:
        return "fresh"
    if sha256(p.read_bytes()) == rec["sha256"]:
        # same content, new timestamp: remember the new stat for next time
        vdb.set_file(db, path, rec["repo"], rec["sha256"], st.st_mtime_ns,
                     st.st_size)
        return "fresh"
    return "changed"


def current_qualnames(path):
    """Function names in the file as it is on disk right now."""
    try:
        return {c["qualname"] for c in get_chunks(path)}
    except OSError:
        return set()


# ---- writing ---------------------------------------------------------------

def _repo_of(db, path):
    rec = vdb.get_file(db, path)
    repo = rec["repo"] if rec else vdb.repo_for_path(db, path)
    if repo is None:
        raise ValueError(f"{path} is not inside any indexed repo")
    return repo


def index_file(db, path, repo=None):
    """(Re)index one file, embedding only functions that are new or changed.

    Returns {"added": n, "removed": n, "kept": n}.
    """
    path = norm_path(path)
    stats, to_embed = _sync_file(db, path, repo or _repo_of(db, path))
    _embed_and_store(db, to_embed)
    return stats


def _embed_and_store(db, chunks, progress=False):
    if chunks:
        vectors = embed_documents([embedding_text(c) for c in chunks],
                                  progress=progress)
        for c, v in zip(chunks, vectors):
            vdb.insert_chunk(db, c, c["repo"], name_text(c), v)


def _sync_file(db, path, repo):
    """Do everything for one file except embedding: keep unchanged chunks,
    delete vanished ones, record the file's hash. Returns (stats, chunks
    still to embed) - so many files' chunks can be embedded in one batch,
    which is much faster than many small batches."""
    path = norm_path(path)
    p = Path(path)
    data = p.read_bytes()
    st = p.stat()
    new_chunks, imports = parse_file(path, data)
    vdb.set_imports(db, path, imports)
    for c in new_chunks:
        c["repo"] = repo

    # Existing chunks of this file, by (qualname, code_hash). A list per key
    # because a file can define the same function twice (e.g. in if/else).
    old = {}
    for row in db.execute("SELECT id, qualname, code_hash FROM chunks"
                          " WHERE kind = 'code' AND file = ?", (path,)):
        old.setdefault((row["qualname"], row["code_hash"]), []).append(row["id"])

    to_embed, kept = [], 0
    for c in new_chunks:
        ids = old.get((c["qualname"], c["code_hash"]))
        if ids:
            # Unchanged function: keep its embedding, just update its lines.
            # (its calls keep line offsets relative to its start, so they
            # stay right too)
            db.execute("UPDATE chunks SET start_line = ?, end_line = ?"
                       " WHERE id = ?", (c["start_line"], c["end_line"], ids.pop()))
            kept += 1
        else:
            to_embed.append(c)
    removed = [i for ids in old.values() for i in ids]
    vdb.delete_chunks(db, removed)
    vdb.set_file(db, path, repo, sha256(data), st.st_mtime_ns, st.st_size)
    return ({"added": len(to_embed), "removed": len(removed), "kept": kept},
            to_embed)


def remove_file(db, path):
    return vdb.delete_file(db, norm_path(path))


def refresh_file(db, path):
    """Bring one file's index up to date: re-index it, or drop it if it's gone."""
    if Path(path).is_file():
        return index_file(db, path)
    return {"added": 0, "removed": remove_file(db, path), "kept": 0}


def index_repo(repo_path, db, name=None, full=False, progress=True):
    """Sync one repo's index with its folder: index new and changed files,
    drop deleted ones, skip unchanged ones. full=True rebuilds this repo's
    code from scratch. Notes and other repos are never touched.

    name: what to call the repo (default: its folder name, e.g.
    'my-project'). Returns stats including the name used.
    """
    root = Path(norm_path(repo_path))
    if name is None:  # already registered? keep its name
        known = {r["root"]: r["name"] for r in vdb.get_repos(db)}
        name = known.get(str(root)) or vdb.default_repo_name(root)
    vdb.add_repo(db, name, str(root))
    if full:
        vdb.clear_code(db, name)
    files = [norm_path(f) for f in find_files(root)]
    stats = {"repo": name, "files": len(files), "changed": 0, "deleted": 0,
             "added": 0, "removed": 0}

    todo = [f for f in files if file_status(db, f) != "fresh"]
    gone = set(vdb.tracked_files(db, repo=name)) - set(files)
    to_embed = []
    for f in todo:
        s, chunks = _sync_file(db, f, name)
        to_embed += chunks
        stats["added"] += s["added"]
        stats["removed"] += s["removed"]
    if progress and to_embed:
        print(f"embedding {len(to_embed)} functions from {len(todo)}"
              f" new/changed of {len(files)} files...")
    _embed_and_store(db, to_embed, progress=progress)
    for f in gone:
        stats["removed"] += remove_file(db, f)
    stats["changed"], stats["deleted"] = len(todo), len(gone)
    db.commit()
    stats["chunks"] = vdb.count_chunks(db, repo=name)
    return stats
