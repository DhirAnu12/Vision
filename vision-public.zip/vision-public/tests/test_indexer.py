from conftest import write_repo
from vision.indexer import embedding_text, find_files, get_chunks, name_text


def test_find_files_skips_venv_and_hidden(repo):
    names = {p.relative_to(repo).as_posix() for p in find_files(repo)}
    assert names == {"voice/agent.py", "tools/web.py"}


def test_repo_inside_hidden_parent_folder_is_still_indexed(tmp_path):
    root = write_repo(tmp_path / ".projects" / "repo")
    assert len(find_files(root)) == 2


def test_chunks_have_qualified_names(repo):
    chunks = get_chunks(repo / "voice/agent.py")
    assert [c["qualname"] for c in chunks] == [
        "_build_stt", "generate_tts", "VoiceAgent.__init__", "VoiceAgent.ready"]


def test_nested_functions_and_decorators(repo):
    chunks = {c["qualname"]: c for c in get_chunks(repo / "tools/web.py")}
    inner = chunks["register.summarize_page"]
    assert inner["code"].startswith("@mcp.tool()")
    # start_line points at the decorator, not the def
    assert inner["start_line"] == 2


def test_abbreviations_in_names_reach_keyword_index_body_ones_only_embeddings(repo):
    stt, _, init, _ = get_chunks(repo / "voice/agent.py")
    assert "speech to text" in name_text(stt)
    # __init__ only *uses* stt/tts: no expansion in its keyword text...
    assert "speech" not in name_text(init)
    # ...but the embedding still gets them
    assert "speech to text, text to speech" in embedding_text(init)


def test_crlf_line_endings_are_normalised(tmp_path):
    f = tmp_path / "win.py"
    f.write_bytes(b"def a():\r\n    return 1\r\n")
    assert get_chunks(f)[0]["code"] == "def a():\n    return 1"
