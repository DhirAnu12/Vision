"""MCP server tests: in-process (fast) and over real stdio (as Claude Code
runs it)."""
import asyncio
import sqlite3
import sys
from contextlib import closing

from mcp import Client
from mcp.client.stdio import StdioServerParameters

from vision.server import server


def _text(result):
    return "".join(c.text for c in result.content if c.type == "text")


def _copy_db(indexed_db, tmp_path):
    """Each test gets its own copy so `remember` doesn't leak into others."""
    db, _, _ = indexed_db
    copy = str(tmp_path / "copy.db")
    # sqlite's backup API, not a file copy: in WAL mode recent writes may
    # still sit in the -wal file next to the database.
    with closing(sqlite3.connect(copy)) as dst:
        db.backup(dst)
    return copy


def test_tools_are_listed():
    async def run():
        async with Client(server) as client:
            return await client.list_tools()
    tools = {t.name: t for t in asyncio.run(run()).tools}
    assert set(tools) == {"search", "remember"}
    assert set(tools["search"].input_schema["properties"]) == {"query", "k", "repo", "graph"}
    assert set(tools["remember"].input_schema["properties"]) == {"note", "tags"}


def test_remember_then_search(indexed_db, tmp_path, monkeypatch):
    monkeypatch.setenv("VISION_DB", _copy_db(indexed_db, tmp_path))

    async def run():
        async with Client(server) as client:
            saved = await client.call_tool("remember", {
                "note": "Whisper was dropped because it was too slow for Hindi.",
                "tags": ["decision", "stt"]})
            found = await client.call_tool("search", {
                "query": "why was whisper dropped", "k": 3})
            code = await client.call_tool("search", {"query": "speech to text"})
            # plain text only, no JSON {"result": ...} copy alongside
            assert saved.structured_content is None
            assert code.structured_content is None
            return _text(saved), _text(found), _text(code)

    saved, found, code = asyncio.run(run())
    assert saved.startswith("Saved note #")
    assert found.startswith("1. [note #") and "tags: decision, stt" in found
    # _build_stt ties with generate_tts in this tiny repo (see test_search)
    assert "[STRONG] _build_stt  (repo)" in code and "def _build_stt" in code


def test_empty_index_gives_helpful_message(tmp_path, monkeypatch):
    monkeypatch.setenv("VISION_DB", str(tmp_path / "empty.db"))

    async def run():
        async with Client(server) as client:
            return _text(await client.call_tool("search", {"query": "x"}))
    assert "index is empty" in asyncio.run(run())


def test_stdio_end_to_end(indexed_db, tmp_path):
    """Launch `python -m vision serve` exactly like Claude Code would."""
    params = StdioServerParameters(
        command=sys.executable, args=["-m", "vision", "serve"],
        env={"VISION_DB": _copy_db(indexed_db, tmp_path)})

    async def run():
        async with Client(params, read_timeout_seconds=120) as client:
            return _text(await client.call_tool("search", {"query": "stt", "k": 1}))
    assert asyncio.run(run()).startswith("1. [STRONG] _build_stt  (repo)")
