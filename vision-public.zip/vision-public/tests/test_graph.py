"""Phase 4: call graph extraction and resolution."""
import os
import textwrap

import pytest

from vision import db as vdb
from vision import graph
from vision.indexer import get_chunks, index_repo
from vision.search import format_results, search

FILES = {
    "store.py": '''
        class Store:
            def __init__(self, path):
                self.path = path
                self._open()

            def _open(self):
                return connect(self.path)

            def save(self, item):
                self._open()
                validate(item)
                return write(item)


        def validate(item):
            return bool(item)


        def make_store():
            return Store("db")
    ''',
    "handlers.py": '''
        import store

        def handle(req):
            s = store.make_store()
            s.save(req)

            def inner():
                return helper()
            return inner()


        def helper():
            return validate(1)
    ''',
    "main.py": '''
        from plugins import a

        def boot():
            a.register()
            loader.register()
    ''',
    # four functions called `register`: `loader.register()` is ambiguous
    **{f"plugins/{m}.py": "def register():\n    return 1\n" for m in "abcd"},
}


@pytest.fixture
def g(tmp_path):
    root = tmp_path / "app"
    for rel, code in FILES.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(textwrap.dedent(code).lstrip())
    db = vdb.connect(str(tmp_path / "g.db"))
    index_repo(root, db, name="app", progress=False)
    ids = {}
    for r in db.execute("SELECT id, qualname, file FROM chunks"):
        key = r["qualname"]
        if key == "register":
            key = "register@" + os.path.basename(r["file"])
        ids[key] = r["id"]
    return db, root, ids


def names(entries):
    return {e["qualname"] for e in entries}


def test_calls_are_recorded_on_the_innermost_function(tmp_path):
    f = tmp_path / "h.py"
    f.write_text(textwrap.dedent(FILES["handlers.py"]))
    chunks = {c["qualname"]: c for c in get_chunks(f)}
    outer = {(c["name"], c["kind"], c["obj"]) for c in chunks["handle"]["calls"]}
    assert outer == {("make_store", "attr", "store"), ("save", "attr", "s"),
                     ("inner", "name", None)}
    assert [c["name"] for c in chunks["handle.inner"]["calls"]] == ["helper"]


def test_self_method_calls(g):
    db, _, ids = g
    assert names(graph.callees(db, ids["Store.save"])) == {"Store._open", "validate"}
    assert names(graph.callers(db, ids["Store._open"])) == {"Store.__init__", "Store.save"}


def test_constructor_call_links_to_init(g):
    db, _, ids = g
    assert names(graph.callees(db, ids["make_store"])) == {"Store.__init__"}
    assert names(graph.callers(db, ids["Store.__init__"])) == {"make_store"}


def test_module_attr_nested_and_cross_file_calls(g):
    db, _, ids = g
    assert names(graph.callees(db, ids["handle"])) == {
        "make_store",      # store.make_store(): module store.py
        "Store.save",      # s.save(): the only `save` in the repo
        "handle.inner"}    # nested function
    assert names(graph.callees(db, ids["handle.inner"])) == {"helper"}
    assert names(graph.callers(db, ids["validate"])) == {"Store.save", "helper"}


def test_ambiguous_calls_are_dropped_but_module_calls_resolve(g):
    db, _, ids = g
    callees = graph.callees(db, ids["boot"])
    # a.register() -> plugins/a.py; loader.register() has 4 candidates: skipped
    assert [c["id"] for c in callees] == [ids["register@a.py"]]


def test_caller_line_is_the_call_site(g):
    db, root, ids = g
    (caller,) = graph.callers(db, ids["make_store"])
    assert caller["qualname"] == "handle"
    line = (root / "handlers.py").read_text().splitlines()[caller["line"] - 1]
    assert "store.make_store()" in line


def test_graph_survives_reindexing_another_file(g):
    db, root, ids = g
    f = root / "store.py"
    f.write_text("# moved down\n\n" + f.read_text().replace(
        "return write(item)", "return write(item, fast=True)"))
    index_repo(root, db, progress=False)
    new_save = db.execute("SELECT id FROM chunks WHERE qualname = 'Store.save'"
                          ).fetchone()[0]
    assert new_save != ids["Store.save"]      # changed function -> new row
    assert names(graph.callers(db, ids["validate"])) == {"Store.save", "helper"}
    assert names(graph.callees(db, ids["handle"])) >= {"Store.save"}
    # deleted rows took their call sites with them
    assert db.execute("SELECT COUNT(*) FROM calls WHERE caller_id = ?",
                      (ids["Store.save"],)).fetchone()[0] == 0


def test_search_with_graph(g):
    db, _, _ = g
    top = search(db, "validate item", k=1, graph_info=True)[0]
    assert top.name == "validate"
    text = format_results([top])
    assert "called by: helper (handlers.py:13), Store.save (store.py:11)" in text
    assert "calls: (none found)" in text
    # off by default
    assert search(db, "validate item", k=1)[0].callers is None


IMPORT_FILES = {
    "pkg/__init__.py": "",
    "pkg/search.py": "def search(q):\n    return q\n",
    "pkg/server.py": "def search(q):\n    return 'tool'\n",
    "pkg/graph.py": "def callers(x):\n    return x\n",
    "pkg/api.py": (
        "from .search import search\n"
        "from . import graph\n"
        "import pkg.server as srv\n"
        "\n"
        "def handle(q):\n"
        "    graph.callers(q)\n"
        "    srv.search(q)\n"
        "    return search(q)\n"),
    "tests/test_it.py": (
        "from pkg.search import search as find\n"
        "\n"
        "def test_find():\n"
        "    assert find('x')\n"),
}


@pytest.fixture
def imp(tmp_path):
    root = tmp_path / "proj"
    for rel, code in IMPORT_FILES.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(code)
    db = vdb.connect(str(tmp_path / "i.db"))
    index_repo(root, db, name="proj", progress=False)
    return db, root


def _callees_by_file(db, qualname):
    cid = db.execute("SELECT id FROM chunks WHERE qualname = ?", (qualname,)).fetchone()[0]
    return {(c["qualname"], os.path.basename(c["file"])) for c in graph.callees(db, cid)}


def test_imports_are_recorded(imp):
    db, root = imp
    rows = db.execute("SELECT local, module, name FROM imports WHERE file LIKE ?",
                      ("%api.py",)).fetchall()
    assert {tuple(r) for r in rows} == {
        ("search", ".search", "search"), ("graph", ".", "graph"),
        ("srv", "pkg.server", None)}


def test_calls_resolve_through_imports(imp):
    db, _ = imp
    # without imports, `search(q)` would be ambiguous between two files
    assert _callees_by_file(db, "handle") == {
        ("search", "search.py"),    # from .search import search
        ("callers", "graph.py"),    # from . import graph; graph.callers()
        ("search", "server.py")}    # import pkg.server as srv; srv.search()


def test_aliased_absolute_import(imp):
    db, _ = imp
    assert _callees_by_file(db, "test_find") == {("search", "search.py")}


def test_external_imports_and_builtin_methods_get_no_links(tmp_path):
    root = tmp_path / "ext"
    root.mkdir()
    (root / "tools.py").write_text(
        "class Runner:\n"
        "    def run(self):\n        pass\n"
        "    def get(self):\n        pass\n"
        "    def cleanup(self):\n        pass\n"
        "\n"
        "def join(a, b):\n    return a + b\n")
    (root / "main.py").write_text(
        "import subprocess\n"
        "from os.path import join\n"
        "\n"
        "def main(cfg, recorder):\n"
        "    subprocess.run(['ls'])\n"   # external module: not Runner.run
        "    join('a', 'b')\n"           # imported from os.path: not tools.join
        "    cfg.get('x')\n"             # dict-style .get: not Runner.get
        "    recorder.cleanup()\n")      # unknown type: a flagged guess
    db = vdb.connect(str(tmp_path / "e.db"))
    index_repo(root, db, name="ext", progress=False)
    main_id = db.execute("SELECT id FROM chunks WHERE qualname = 'main'").fetchone()[0]
    links = graph.callees(db, main_id)
    assert [(c["qualname"], c["guess"]) for c in links] == [("Runner.cleanup", True)]

    top = search(db, "main recorder cleanup", k=1, graph_info=True)[0]
    text = format_results([top])
    assert "Runner.cleanup?" in text and "(? = call matched by method name only" in text


def test_known_links_are_not_guesses(g):
    db, _, ids = g
    assert not any(c["guess"] for c in graph.callees(db, ids["Store.save"]))
    # `s.save()` - s's type is unknown, so this one is a guess
    handle = {c["qualname"]: c["guess"] for c in graph.callees(db, ids["handle"])}
    assert handle == {"make_store": False, "Store.save": True, "handle.inner": False}
