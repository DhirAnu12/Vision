from vision.text import expansions, fts_query, split_words


def test_split_words_handles_snake_and_camel_case():
    assert split_words("_build_stt") == ["build", "stt"]
    assert split_words("HTTPServer") == ["http", "server"]
    assert split_words("VoiceAgent.__init__") == ["voice", "agent", "init"]
    assert split_words("STT_PROVIDER") == ["stt", "provider"]


def test_expansions_match_whole_words_only():
    assert expansions("def _build_stt(): ...") == ["speech to text"]
    # 'stt' inside a longer word is not the abbreviation
    assert expansions("settings = 1") == []


def test_fts_query_has_phrase_then_words_without_stopwords():
    assert fts_query("speech to text") == '"speech to text" OR "speech" OR "text"'
    assert fts_query("stt") == '"stt"'


def test_fts_query_neutralises_fts_syntax():
    q = fts_query('weird -* "quotes" OR( input')
    assert '*' not in q and '(' not in q and '-' not in q


def test_fts_query_returns_none_when_nothing_left():
    assert fts_query("the to of") is None
    assert fts_query("?!") is None
