import sqlite3

from vision import db as vdb
from vision.cli import main
from vision.indexer import index_repo
from vision.search import format_results, keyword_search, rrf, search


def test_rrf_rewards_appearing_in_both_lists():
    fused = rrf({"vector": [1, 2, 3], "keyword": [3, 4]}, k=60)
    ids = [i for i, _, _ in fused]
    assert ids[0] == 3  # 3rd + 1st beats a lone 1st
    assert fused[0][2] == {"vector": 3, "keyword": 1}
    assert abs(fused[0][1] - (1 / 63 + 1 / 61)) < 1e-12


def test_speech_to_text_finds_build_stt(indexed_db):
    db, _, _ = indexed_db
    # In this 7-function repo _build_stt and generate_tts tie on RRF score
    # (vector and keyword rank them 1/2 in opposite order), so top 2 is the
    # honest claim. Ranking quality is measured with `vision eval`.
    top2 = [r.name for r in search(db, "speech to text", k=2)]
    assert "_build_stt" in top2


def test_abbreviation_query_finds_it_by_keyword(indexed_db):
    db, _, _ = indexed_db
    assert search(db, "stt", k=1, mode="keyword")[0].name == "_build_stt"


def test_vector_mode_finds_by_meaning(indexed_db):
    db, _, _ = indexed_db
    top = search(db, "store a note in sqlite", k=1, mode="vector")[0]
    assert top.name == "save_note_to_database"


def test_keyword_search_survives_fts_syntax(indexed_db):
    db, _, _ = indexed_db
    keyword_search(db, 'weird -* "quotes" OR( NEAR input')  # must not raise
    assert keyword_search(db, "the of") == []


def test_reindex_does_not_duplicate(indexed_db, tmp_path):
    _, root, _ = indexed_db
    db = vdb.connect(str(tmp_path / "re.db"))
    index_repo(root, db, progress=False)
    first = vdb.count_chunks(db)
    index_repo(root, db, progress=False)
    assert vdb.count_chunks(db) == first == 7


def test_old_schema_is_rebuilt(tmp_path):
    path = str(tmp_path / "old.db")
    old = sqlite3.connect(path)
    old.execute("CREATE TABLE chunks(id INTEGER PRIMARY KEY, file TEXT)")
    old.commit()
    old.close()
    db = vdb.connect(path)
    cols = [r[1] for r in db.execute("PRAGMA table_info(chunks)")]
    assert "qualname" in cols


def test_cli_search_prints_results(indexed_db, capsys):
    _, _, path = indexed_db
    main(["--db", path, "search", "speech to text", "-k", "2"])
    out = capsys.readouterr().out
    assert "[STRONG] _build_stt  (repo)" in out  # rank 1 or 2: see the tie above
    assert "voice" in out and "agent.py:3-6" in out


def test_identical_copies_are_collapsed(tmp_path):
    code = "def transcribe(buf):\n    return whisper.transcribe(buf)\n"
    other = "def record_audio():\n    return mic.read()\n"
    for d in ("copy_a", "copy_b"):
        (tmp_path / "repo" / d).mkdir(parents=True)
        (tmp_path / "repo" / d / "audio.py").write_text(code + "\n" + other)
    db = vdb.connect(str(tmp_path / "d.db"))
    index_repo(tmp_path / "repo", db, progress=False)

    results = search(db, "transcribe audio", k=2)
    # 4 chunks, but only 2 different functions: both fit in k=2
    assert {r.name for r in results} == {"transcribe", "record_audio"}
    assert all(len(r.also_in) == 1 for r in results)
    text = format_results(results)
    assert text.count("(identical)") == 2
