"""Phase 4: several repos in one database."""
import pytest

from vision import db as vdb
from vision.cli import main
from vision.indexer import index_file, index_repo
from vision.search import search, vector_search


def _repo(root, files):
    root.mkdir(parents=True)
    for name, code in files.items():
        (root / name).write_text(code)
    return root


@pytest.fixture
def two(tmp_path):
    # repo "big" has many audio functions; repo "small" has exactly one
    big = _repo(tmp_path / "big", {
        f"audio{i}.py": f"def record_audio_{i}():\n    return mic.record({i})\n"
        for i in range(8)})
    small = _repo(tmp_path / "small", {
        "rec.py": "def capture_microphone():\n    return mic.capture()\n"})
    db = vdb.connect(str(tmp_path / "m.db"))
    index_repo(big, db, name="big", progress=False)
    index_repo(small, db, name="small", progress=False)
    return db, big, small, str(tmp_path / "m.db")


def test_default_repo_name():
    assert vdb.default_repo_name("C:/Users/me/Code/My Project") == "my-project"


def test_repos_are_listed_and_tagged(two):
    db, *_ = two
    assert [r["name"] for r in vdb.get_repos(db)] == ["big", "small"]
    assert vdb.count_chunks(db, repo="big") == 8
    assert vdb.count_chunks(db, repo="small") == 1


def test_search_all_or_one_repo(two):
    db, *_ = two
    everywhere = {r.repo for r in search(db, "record from microphone", k=10)}
    assert everywhere == {"big", "small"}
    only = search(db, "record from microphone", k=10, repo="small")
    assert [r.name for r in only] == ["capture_microphone"]


def test_filter_happens_inside_knn(two):
    """Asking for 1 nearest neighbour *within* small must find small's
    function, even though big has closer ones. (Filtering after the KNN
    would return nothing.)"""
    db, *_ = two
    ids = vector_search(db, "record audio", n=1, repo="small")
    row = db.execute("SELECT qualname FROM chunks WHERE id = ?", ids).fetchone()
    assert row[0] == "capture_microphone"


def test_notes_show_up_for_every_repo(two):
    db, *_ = two
    vdb.insert_note(db, "Microphone capture must use 16 kHz mono.", ["audio"])
    db.commit()
    for repo in ("big", "small", None):
        kinds = {r.kind for r in search(db, "microphone sample rate", k=3, repo=repo)}
        assert "note" in kinds


def test_unknown_repo_lists_known_ones(two):
    db, *_ = two
    with pytest.raises(ValueError, match="indexed repos: big, small"):
        search(db, "x", repo="nope")


def test_name_and_folder_conflicts(two, tmp_path):
    db, big, small, _ = two
    other = _repo(tmp_path / "other", {"x.py": "def x():\n    pass\n"})
    with pytest.raises(ValueError, match="already used"):
        index_repo(other, db, name="big", progress=False)
    with pytest.raises(ValueError, match="already indexed as 'big'"):
        index_repo(big, db, name="big2", progress=False)
    nested = _repo(big / "sub", {"y.py": "def y():\n    pass\n"})
    with pytest.raises(ValueError, match="overlaps"):
        index_repo(nested, db, name="sub", progress=False)


def test_reindex_without_name_keeps_name(two):
    db, big, *_ = two
    assert index_repo(big, db, progress=False)["repo"] == "big"


def test_files_stay_in_their_repo(two):
    db, _, small, _ = two
    f = small / "new.py"
    f.write_text("def new_fn():\n    pass\n")
    index_file(db, f)  # repo found from the folder
    assert db.execute("SELECT repo FROM chunks WHERE qualname = 'new_fn'"
                      ).fetchone()[0] == "small"


def test_full_reindex_and_remove_touch_one_repo_only(two):
    db, big, *_ = two
    vdb.insert_note(db, "keep me", [])
    db.commit()
    index_repo(big, db, full=True, progress=False)
    assert vdb.count_chunks(db, repo="small") == 1
    vdb.remove_repo(db, "big")
    db.commit()
    assert [r["name"] for r in vdb.get_repos(db)] == ["small"]
    assert vdb.count_chunks(db, repo="big") == 0
    assert vdb.count_chunks(db, "note") == 1


def test_cli_repos_and_filter(two, capsys):
    *_, path = two
    main(["--db", path, "repos"])
    out = capsys.readouterr().out
    assert "big" in out and "small" in out
    main(["--db", path, "search", "microphone", "--repo", "small", "-k", "1"])
    assert "(small)" in capsys.readouterr().out
