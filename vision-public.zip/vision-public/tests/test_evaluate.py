"""Phase 5: benchmark metrics, runner and report."""
import json

import pytest

from vision import evaluate
from vision.cli import main
from vision.evaluate import (first_rank, hit_at, recall_at, reciprocal_rank,
                             summarize)
from vision.search import rrf


def test_first_rank_and_reciprocal_rank():
    ranked = ["a", "b", "c", "d"]
    assert first_rank(ranked, {"c", "d"}) == 3
    assert reciprocal_rank(ranked, {"c", "d"}) == pytest.approx(1 / 3)
    assert first_rank(ranked, {"z"}) is None
    assert reciprocal_rank(ranked, {"z"}) == 0.0
    # beyond the MRR depth counts as a miss
    assert reciprocal_rank(["x"] * 10 + ["a"], {"a"}) == 0.0


def test_hit_and_recall():
    ranked = ["a", "b", "c", "d", "e", "f"]
    assert hit_at(ranked, {"e"}) and not hit_at(ranked, {"f"})
    assert recall_at(ranked, {"a", "f"}) == 0.5
    # denominator capped at k: all 5 slots correct = 1.0 even with 7 answers
    assert recall_at(ranked, set("abcdefg")) == 1.0


def test_summarize_averages():
    rows = [{"hit": True, "recall": 1.0, "rr": 1.0},
            {"hit": False, "recall": 0.0, "rr": 0.0}]
    assert summarize(rows) == {"n": 2, "hit": 0.5, "recall": 0.5, "mrr": 0.5}


def test_weighted_rrf():
    fused = rrf({"vector": [1, 2], "keyword": [2]}, k=60, weights={"keyword": 0.5})
    scores = {i: s for i, s, _ in fused}
    assert scores[1] == pytest.approx(1 / 61)
    assert scores[2] == pytest.approx(1 / 62 + 0.5 / 61)


@pytest.fixture
def bench(indexed_db, tmp_path):
    db, root, path = indexed_db
    data = {"repo": "repo", "queries": [
        {"type": "paraphrase", "query": "speech to text", "relevant": ["_build_stt"]},
        {"type": "identifier", "query": "save note to database",
         "relevant": ["save_note_to_database"]},
        {"type": "paraphrase", "query": "something nobody wrote",
         "relevant": ["register"]},
    ]}
    f = tmp_path / "b.json"
    f.write_text(json.dumps(data))
    return db, path, f


def test_validate_catches_typos(bench):
    db, _, f = bench
    data = evaluate.load(f)
    data["queries"][0]["relevant"] = ["_build_sst"]
    with pytest.raises(ValueError, match="_build_sst"):
        evaluate.validate(db, data)


def test_run_and_report(bench):
    db, _, f = bench
    data = evaluate.load(f)
    configs = {"hybrid + prefix": evaluate.CONFIGS["hybrid + prefix"],
               "vector + prefix": evaluate.CONFIGS["vector + prefix"]}
    res = evaluate.run(db, data, configs)
    rows = res["hybrid + prefix"]["rows"]
    assert rows[0]["rank"] in (1, 2)  # tie with generate_tts, see test_search
    assert rows[1]["rank"] == 1
    assert not rows[2]["hit"]  # found, but outside the top 5
    text = evaluate.report(data, res)
    assert "| **hybrid + prefix** |" in text
    assert "### Paraphrase queries only" in text and "## Per query" in text


def test_cli_eval_writes_report(bench, tmp_path, capsys):
    _, path, f = bench
    out = tmp_path / "r.md"
    main(["--db", path, "eval", str(f), "--out", str(out)])
    assert out.read_text(encoding="utf-8").startswith("# Vision search benchmark: repo")
    assert "hit@5" in capsys.readouterr().out
