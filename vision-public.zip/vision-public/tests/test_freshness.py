"""Phase 3: hashes, verdicts, incremental indexing and watch mode."""
import os
import threading
import time

import pytest

from vision import db as vdb
from vision import indexer
from vision.indexer import file_status, index_file, index_repo, norm_path
from vision.search import format_results, search
from vision.watch import watch

AUDIO = '''\
def transcribe_audio(buf):
    """Speech to text with whisper."""
    return whisper.transcribe(buf)


def play_sound(path):
    return speaker.play(path)
'''


@pytest.fixture
def small(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    (root / "audio.py").write_text(AUDIO)
    (root / "other.py").write_text("def unrelated_helper():\n    return 42\n")
    db = vdb.connect(str(tmp_path / "f.db"))
    index_repo(root, db, progress=False)
    return db, root


def _edit(path, text):
    """Write and make sure mtime visibly moves (coarse clocks on Windows)."""
    path.write_text(text)
    st = path.stat()
    os.utime(path, ns=(st.st_atime_ns, st.st_mtime_ns + 2_000_000_000))


@pytest.fixture
def embed_counter(monkeypatch):
    """Count how many texts get embedded (embedding is the slow part)."""
    calls = []
    real = indexer.embed_documents

    def counting(texts, progress=False):
        calls.extend(texts)
        return real(texts, progress)
    monkeypatch.setattr(indexer, "embed_documents", counting)
    return calls


def test_hashes_are_stored(small):
    db, root = small
    rec = vdb.get_file(db, norm_path(root / "audio.py"))
    assert len(rec["sha256"]) == 64
    hashes = [r[0] for r in db.execute("SELECT code_hash FROM chunks")]
    assert len(hashes) == 3 and all(len(h) == 64 for h in hashes)


def test_file_status(small):
    db, root = small
    f = root / "audio.py"
    assert file_status(db, f) == "fresh"
    _edit(f, AUDIO)                       # saved, but same content
    assert file_status(db, f) == "fresh"
    _edit(f, AUDIO + "\n# comment\n")
    assert file_status(db, f) == "changed"
    f.unlink()
    assert file_status(db, f) == "deleted"
    assert file_status(db, root / "new.py") == "untracked"


def test_verdict_strong(small):
    db, _ = small
    top = search(db, "speech to text", k=1)[0]
    assert (top.name, top.verdict) == ("transcribe_audio", "STRONG")


def test_verdict_stale_without_refresh(small):
    db, root = small
    _edit(root / "audio.py", "# new header\n" + AUDIO)
    top = search(db, "speech to text", k=1, refresh=False)[0]
    assert (top.name, top.verdict) == ("transcribe_audio", "STALE")
    assert "may be out of date" in format_results([top])


def test_verdict_dead_without_refresh(small):
    db, root = small
    _edit(root / "audio.py", "def play_sound(path):\n    return speaker.play(path)\n")
    top = search(db, "speech to text", k=1, refresh=False)[0]
    assert (top.name, top.verdict) == ("transcribe_audio", "DEAD")


def test_verdict_rebuilt_gives_current_code(small):
    db, root = small
    _edit(root / "audio.py", "\n\n" + AUDIO.replace("whisper.transcribe",
                                                    "cloud.transcribe"))
    top = search(db, "speech to text", k=1)[0]
    assert (top.name, top.verdict) == ("transcribe_audio", "REBUILT")
    assert "cloud.transcribe" in top.text      # fresh code, not the old one
    assert top.start_line == 3                  # fresh line numbers
    # and the index itself is now up to date
    assert file_status(db, root / "audio.py") == "fresh"


def test_deleted_function_reported_dead_after_refresh(small):
    db, root = small
    _edit(root / "audio.py", "def play_sound(path):\n    return speaker.play(path)\n")
    results = search(db, "speech to text", k=2)
    dead = [r for r in results if r.verdict == "DEAD"]
    assert [r.name for r in dead] == ["transcribe_audio"]
    assert all(r.verdict == "STRONG" or r.verdict == "REBUILT"
               for r in results if r.verdict != "DEAD")
    assert "No longer exist" in format_results(results)
    assert db.execute("SELECT COUNT(*) FROM chunks WHERE qualname ="
                      " 'transcribe_audio'").fetchone()[0] == 0


def test_deleted_file_is_dead(small):
    db, root = small
    (root / "audio.py").unlink()
    top = search(db, "speech to text", k=1, refresh=False)[0]
    assert top.verdict == "DEAD"


def test_index_file_only_embeds_changed_functions(small, embed_counter):
    db, root = small
    f = root / "audio.py"
    before = {r["qualname"]: r["id"] for r in db.execute(
        "SELECT id, qualname FROM chunks WHERE file = ?", (norm_path(f),))}
    _edit(f, "import os\n\n" + AUDIO.replace("speaker.play", "speaker.play_now"))
    stats = index_file(db, f)
    assert stats == {"added": 1, "removed": 1, "kept": 1}
    assert len(embed_counter) == 1 and "play_now" in embed_counter[0]
    after = {r["qualname"]: r for r in db.execute(
        "SELECT id, qualname, start_line FROM chunks WHERE file = ?",
        (norm_path(f),))}
    # untouched function kept its row (and embedding), but moved down 2 lines
    assert after["transcribe_audio"]["id"] == before["transcribe_audio"]
    assert after["transcribe_audio"]["start_line"] == 3


def test_index_repo_skips_unchanged_files(small, embed_counter):
    db, root = small
    stats = index_repo(root, db, progress=False)
    assert stats["changed"] == 0 and embed_counter == []
    (root / "new.py").write_text("def brand_new():\n    pass\n")
    (root / "other.py").unlink()
    stats = index_repo(root, db, progress=False)
    assert (stats["changed"], stats["deleted"]) == (1, 1)
    assert len(embed_counter) == 1
    names = {r[0] for r in db.execute("SELECT qualname FROM chunks")}
    assert names == {"transcribe_audio", "play_sound", "brand_new"}


def test_full_reindex_keeps_notes(small):
    db, root = small
    vdb.insert_note(db, "a note", ["x"])
    db.commit()
    index_repo(root, db, full=True, progress=False)
    assert vdb.count_chunks(db, "note") == 1
    assert vdb.count_chunks(db, "code") == 3


def _wait_for(check, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        if check():
            return True
        time.sleep(0.2)
    return False


def test_watch_mode_reindexes_only_changed_files(tmp_path):
    root = tmp_path / "repo"
    (root / "pkg").mkdir(parents=True)
    (root / "a.py").write_text("def alpha():\n    return 1\n")
    (root / "pkg" / "b.py").write_text("def beta():\n    return 2\n")
    db_path = str(tmp_path / "w.db")
    logs, stop = [], threading.Event()
    t = threading.Thread(target=watch, args=(root, db_path, stop, logs.append),
                         kwargs={"debounce": 0.3}, daemon=True)
    t.start()
    try:
        assert _wait_for(lambda: logs and logs[0].startswith("watching"))
        names = lambda: {r[0] for r in vdb.connect(db_path).execute(
            "SELECT qualname FROM chunks")}
        assert names() == {"alpha", "beta"}

        (root / "a.py").write_text("def alpha_renamed():\n    return 1\n")
        assert _wait_for(lambda: names() == {"alpha_renamed", "beta"})
        assert not any("b.py" in line for line in logs)  # b.py not touched

        (root / "pkg" / "b.py").unlink()
        assert _wait_for(lambda: names() == {"alpha_renamed"})

        (root / "venv").mkdir()
        (root / "venv" / "junk.py").write_text("def ignored():\n    pass\n")
        (root / "c.py").write_text("def gamma():\n    pass\n")
        assert _wait_for(lambda: "gamma" in names())
        assert "ignored" not in names()
    finally:
        stop.set()
        t.join(timeout=10)
