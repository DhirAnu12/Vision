import textwrap

import pytest

from vision import db as vdb
from vision.indexer import index_repo

FILES = {
    "voice/agent.py": '''
        STT_PROVIDER = "local"

        def _build_stt():
            if STT_PROVIDER == "local":
                return local_asr.STT(language="en-US")
            return openai.STT(model="whisper-1")

        def generate_tts(text):
            """Turn a reply into audio."""
            return tts_engine.speak(text)

        class VoiceAgent(Agent):
            def __init__(self, stt, tts):
                self.stt = stt
                self.tts = tts

            @property
            def ready(self):
                return True
    ''',
    "tools/web.py": '''
        def register(mcp):
            @mcp.tool()
            def summarize_page(url):
                return fetch(url)[:500]

        def save_note_to_database(conn, note):
            conn.execute("INSERT INTO notes VALUES (?)", (note,))
            conn.commit()
    ''',
    # These must be skipped by find_files.
    "venv/lib/junk.py": "def should_not_be_indexed(): pass\n",
    ".hidden/secret.py": "def also_not_indexed(): pass\n",
}


def write_repo(root):
    for rel, code in FILES.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(textwrap.dedent(code).lstrip(), encoding="utf-8")
    return root


@pytest.fixture
def repo(tmp_path):
    return write_repo(tmp_path / "repo")


@pytest.fixture(scope="session")
def indexed_db(tmp_path_factory):
    """A small repo indexed once with the real model (shared by tests)."""
    base = tmp_path_factory.mktemp("indexed")
    root = write_repo(base / "repo")
    db = vdb.connect(str(base / "test.db"))
    index_repo(root, db, progress=False)
    yield db, root, str(base / "test.db")
    db.close()
