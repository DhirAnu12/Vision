from vision import db as vdb
from vision.indexer import index_repo
from vision.search import format_results, search


def test_note_is_searchable_by_meaning_and_tags(repo, tmp_path):
    db = vdb.connect(str(tmp_path / "n.db"))
    index_repo(repo, db, progress=False)
    note_id = vdb.insert_note(
        db, "We picked the local engine over the cloud one because the cloud "
            "was too slow for live audio.", ["decision", "stt"])
    db.commit()

    top = search(db, "why did we choose the local engine", k=1)[0]
    assert (top.kind, top.id) == ("note", note_id)
    assert top.tags == ["decision", "stt"]
    # keyword search finds it via its tag
    hits = search(db, "decision", k=3, mode="keyword")
    assert any(r.kind == "note" for r in hits)


def test_reindex_keeps_notes(repo, tmp_path):
    db = vdb.connect(str(tmp_path / "n.db"))
    index_repo(repo, db, progress=False)
    vdb.insert_note(db, "Keep the overlay at 30fps.", "perf")
    db.commit()
    index_repo(repo, db, progress=False)
    assert vdb.count_chunks(db, "note") == 1
    assert vdb.count_chunks(db, "code") == 7
    # the deleted code chunks are gone from both indexes, too
    n_vec = db.execute("SELECT COUNT(*) FROM vec_chunks").fetchone()[0]
    n_fts = db.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0]
    assert n_vec == n_fts == 8


def test_schema_change_carries_notes_over(tmp_path):
    path = str(tmp_path / "n.db")
    db = vdb.connect(path)
    vdb.insert_note(db, "Tags are comma separated.", ["convention"],
                    created_at="2026-01-02T03:04:05+00:00")
    db.execute("PRAGMA user_version = 1")  # pretend the schema is outdated
    db.commit()
    db.close()

    db = vdb.connect(path)  # triggers rebuild
    row = db.execute("SELECT * FROM chunks WHERE kind = 'note'").fetchone()
    assert row["code"] == "Tags are comma separated."
    assert row["tags"] == "convention"
    assert row["created_at"] == "2026-01-02T03:04:05+00:00"
    assert search(db, "comma separated tags", k=1)[0].kind == "note"


def test_format_results_truncates_long_code(indexed_db):
    db, _, _ = indexed_db
    r = search(db, "speech to text", k=1)[0]
    r.text = "\n".join(f"line {i}" for i in range(100))
    text = format_results([r], max_lines=10)
    assert "line 9" in text and "line 10" not in text
    assert "(90 more lines)" in text
