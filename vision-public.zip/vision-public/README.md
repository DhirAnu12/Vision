# Vision

A local memory and search layer for AI coding agents.

Vision indexes your Python repos function by function and lets you (or an
agent such as Claude Code, over MCP) ask questions like *"where is speech
to text set up?"* and get back the right functions, with file paths, line
numbers and code. It also remembers notes ("we chose X because Y") that
show up in the same searches.

Everything runs on your machine: no API keys, and no network after the
embedding model's first download.

**What it does**

- **Hybrid search.** Combines meaning (embeddings) with exact words (SQLite
  full-text search), and knows common code abbreviations (`stt` = "speech
  to text").
- **Notes.** `remember` saves decisions and gotchas; `search` finds them
  next to the code.
- **Trust verdicts.** Every hit says whether its code is current
  (`STRONG`, `REBUILT`), possibly outdated (`STALE`) or gone (`DEAD`).
  Changed files are re-indexed on the fly.
- **Incremental and watch mode.** Only new or changed functions are
  re-embedded; `vision watch` keeps the index in sync as you save.
- **Multiple repos.** One database, filter by repo name.
- **Call graph.** Optionally shows what each result calls and what calls it.
- **MCP server.** `search` and `remember` tools for Claude Code.
- **Benchmark tool.** Measures search quality (hit@5, recall@5, MRR) on
  your own labelled queries.

## Quick start

**1. Install** (from this folder, in PowerShell):

```powershell
python -m venv venv
.\venv\Scripts\activate
pip install -e ".[dev]"
```

**2. Index a project and try a search:**

```powershell
vision index C:/path/to/myapp --name myapp
vision search "where are uploads retried" --code
```

The first run downloads the embedding model (~130 MB) and embeds every
function, so it can take a minute or two. Later runs only process changed
files.

**3. Connect it to Claude Code** (once, for all projects):

```powershell
claude mcp add vision --transport stdio --scope user --env VISION_DB=C:/path/to/vision/vision.db -- C:/path/to/vision/venv/Scripts/vision.exe serve
claude mcp list            # should show: vision ... ✓ Connected
```

Start a new Claude Code session; `/mcp` should list `vision`.

**4. Keep the index fresh while you work** (optional, in its own terminal):

```powershell
vision watch C:/path/to/myapp
```

Without it, searches still re-index changed files on the fly, so results
are never silently out of date.

**5. Ask Claude.** Prompts that work well:

- *"Use vision to find where uploads are retried."*
- *"Search vision for how the config file is loaded, then explain it."*
- *"Before changing `save_user`, use vision with graph on to see what calls it."*
- *"Remember that we retry uploads 3 times because the storage API drops
  requests under load. Tag it decision, upload."*
- *"Check vision's notes: why did we choose this retry limit?"*

**6. Make it a habit** (optional): add this to the project's `CLAUDE.md`
so Claude uses Vision without being asked:

```markdown
## Code search
- Before reading files to find code, use the `vision` MCP `search` tool
  (repo: "myapp"). Trust STRONG/REBUILT results; re-check STALE ones.
- Use `search` with `graph: true` before changing a function, to see its callers.
- When we make a decision or hit a gotcha, save it with `remember`
  (tags like "decision", "gotcha") so future sessions can find it.
```

The sections below explain each part in detail.

## Setup (Windows, Python 3.11)

The install commands are in the quick start. `-e` (editable) installs the `vision` command but keeps running the code
from this folder, so edits take effect immediately. The embedding model
(`BAAI/bge-small-en-v1.5`, ~130 MB) downloads on first use and is cached.

## Usage

```powershell
vision index C:/path/to/myapp --name myapp   # index a repo (only new/changed files)
vision index C:/path/to/myapp --full         # rebuild that repo from scratch
vision watch C:/path/to/myapp                # keep it in sync while you edit
vision repos                                 # list indexed repos
vision remove myapp                          # drop a repo (notes are kept)

vision search "speech to text"
vision search "speech to text" --repo myapp  # one repo only
vision search "speech to text" --graph       # + callers / callees
vision search "speech to text" -k 10 --code  # more results, show code
vision search "speech to text" --mode vector # or keyword / hybrid (default)
vision search "speech to text" --no-prefix   # skip the bge query prefix
vision search "speech to text" --no-refresh  # report STALE/DEAD, don't re-index

vision remember "We retry uploads 3 times because the API drops requests" --tags decision,upload
```

Each result shows which search methods found it and at what rank, e.g.
`[vector #10, keyword #3]`.

The database is `./vision.db` by default; override it with `--db path` or
the `VISION_DB` environment variable. `python -m vision ...` also works.

### Choosing a search mode

- **hybrid** (default): best when word order or exact names matter
  ("speech to text" vs "text to speech", `_build_stt`). Vector search
  alone tends to confuse the two directions.
- **vector**: often better for longer, paraphrased questions ("stop
  recording once the person stops talking").
- **keyword**: exact words only; mostly useful for comparison.

### Trust verdicts

| Verdict | Meaning |
|---|---|
| `STRONG` | file unchanged since indexing; code and line numbers are current |
| `REBUILT` | file had changed; Vision re-indexed it during this search, so the code is current |
| `STALE` | file changed since indexing; code shown may be out of date (only with `--no-refresh`) |
| `DEAD` | the function no longer exists |

By default a search re-indexes changed files on the spot and runs again,
so you see `REBUILT` rather than `STALE`. Functions that matched but have
since been deleted are listed at the end as `DEAD`.

### Several repos

One database can hold many repos. `--name` sets a repo's name (default:
its folder name, e.g. `C:/Code/My Project` → `my-project`); re-indexing the
same folder later keeps the name. Repo folders can't be nested inside each
other. Results show the repo in brackets: `_build_stt  (myapp) C:\...`.

Notes are global, so they show up whatever repo you filter by. The repo
filter runs *inside* the vector search (a sqlite-vec metadata column), so
a small repo isn't crowded out by a big one.

### Call graph

`--graph` (MCP: `graph=true`) adds two lines per result. Here it is on
Vision's own code:

```
1. [STRONG] reciprocal_rank  (vision) C:\...\vision\evaluate.py:44-46
   calls: first_rank (vision/evaluate.py:25)
   called by: test_first_rank_and_reciprocal_rank (tests/test_evaluate.py:16), run (vision/evaluate.py:90)
```

`calls:` points at each callee's definition and `called by:` at the call
site. Python is dynamic, so these links come from syntax plus a few rules
(see `vision/graph.py`):

- `foo()`: nested/sibling function → class `foo` in the same file → what
  `from x import foo` says → a top-level `foo` elsewhere in the repo.
- `self.foo()`: method in the same class → same file → any method `foo`.
- `mod.foo()`: what `import mod` / `from pkg import mod` says → a file
  `mod.py` or class `mod` → as a last resort any method `foo`. That last
  one is a **guess** and is shown with `?`.
- Imported names that lead outside the repo (`subprocess.run`,
  `from os.path import join`) are external: no link. Calls like `x.get()`
  or `x.append()` are never guessed (almost always dict/list).
- More than 3 candidates is too ambiguous: no link.

Call sites are stored as written and resolved when you ask, so
re-indexing one file never leaves broken links in another.

## MCP server (Claude Code)

`vision serve` runs an MCP server over stdio with two tools:

| Tool | What it does |
|---|---|
| `search(query, k=5, repo=None, graph=False)` | hybrid search over code + notes; returns repo, file paths, line ranges, verdicts, code (max 40 lines each) and notes; `repo` filters, `graph` adds callers/callees |
| `remember(note, tags=None)` | saves a note that later `search` calls can find |

Register it once for all your projects (user scope). Use absolute paths,
since Claude Code may start the server from any folder:

```powershell
claude mcp add vision --transport stdio --scope user --env VISION_DB=C:/path/to/vision/vision.db -- C:/path/to/vision/venv/Scripts/vision.exe serve
claude mcp list            # should show: vision ... ✓ Connected
```

The name (`vision`) must come right after `add`: `--env` accepts several
values, so a name placed after it gets swallowed as another env var
(`error: missing required argument 'name'`).

Without the `claude` CLI on your PATH (e.g. only the VS Code extension),
put this in a `.mcp.json` at the root of the project you're working in
(Claude Code asks you to approve it the first time):

```json
{
  "mcpServers": {
    "vision": {
      "type": "stdio",
      "command": "C:/path/to/vision/venv/Scripts/vision.exe",
      "args": ["serve"],
      "env": { "VISION_DB": "C:/path/to/vision/vision.db" }
    }
  }
}
```

In a Claude Code session, `/mcp` shows the server's status. The server
prints its database path to stderr on start-up; it must never print to
stdout, because that's the protocol channel.

## How it works

```
repo ─► find .py files ─► tree-sitter: one chunk per function/method
                                   │
            ┌──────────────────────┼─────────────────────┐
            ▼                      ▼                     ▼
      chunks (data)      vec_chunks (sqlite-vec)  chunks_fts (FTS5)
                          384-d embedding         name / code
```

- **Chunks** have a qualified name (`VoiceAgent.__init__`,
  `register.summarize_page` for a nested function) and include decorators.
- **Vector search** embeds the query (with the bge prefix) and finds the
  nearest chunk embeddings. Good at meaning, weak at word order.
- **Keyword search** uses SQLite FTS5 with BM25 ranking over two columns,
  weighted name 5 : code 1. The query becomes
  `"speech to text" OR "speech" OR "text"`: the phrase keeps word order,
  the single words catch partial matches.
- **Abbreviations** (`vision/text.py`, `ABBREVIATIONS`): code says `stt`,
  people say "speech to text". An abbreviation in a function's *name*
  (`_build_stt`) is expanded into the keyword index; abbreviations
  anywhere in the code are expanded into the text the model embeds.
  Body abbreviations stay out of the keyword index, because adding "text
  to speech" to every function that uses `tts` made any query with "text"
  match them. Add your own and re-index.
- **Hybrid** merges the two ranked lists with reciprocal rank fusion
  (RRF): each chunk scores `1/(60 + rank)` per list it appears in. Only
  ranks matter, so cosine and BM25 scores never need comparing. Exact
  copies of a function (same name and code, e.g. in a copied project) are
  shown once, with `also in:` lines.

### Freshness and incremental indexing

At index time Vision stores a SHA-256 hash of every file (`files` table)
and of every function (`chunks.code_hash`).

- **Is a file fresh?** First compare its size and modification time with
  what was stored (cheap, no reading). If they differ, hash the content:
  an editor may have re-saved it unchanged, which still counts as fresh.
- **Re-indexing a file** matches its functions by (name, code hash).
  Unchanged ones keep their embedding and only get new line numbers; only
  new or changed functions are embedded, so a no-change `vision index`
  takes seconds instead of minutes.
- Line endings are normalised, so Windows CRLF and Unix LF copies of a
  function count as identical.
- The database uses SQLite **WAL** mode with a 30 s busy timeout, so watch
  mode, the MCP server and the CLI can use it at the same time.

## Evaluating search quality

Write a benchmark file of queries for one indexed repo, each listing every
function (by qualified name) that correctly answers it:

```json
{
  "repo": "myapp",
  "queries": [
    {"type": "paraphrase", "query": "retry a failed upload",
     "relevant": ["upload_with_retry", "Uploader.retry"]},
    {"type": "identifier", "query": "upload retry",
     "relevant": ["upload_with_retry"]}
  ]
}
```

```powershell
vision eval my_benchmark.json --out report.md
```

It runs every query with vector, hybrid and keyword search, with and
without the query prefix, and reports per configuration and per query
type:

- **hit@5**: a correct answer is in the top 5
- **recall@5**: the share of correct answers in the top 5 (out of at most 5)
- **MRR**: the average of 1/rank of the first correct answer (top 10)

Names that don't exist in the repo are rejected up front, so a typo can't
pass for a miss.

Tips for a fair benchmark: describe behaviour without reusing words from
the function's name (or keyword search wins for free); include mirrored
"A to B / B to A" pairs; keep a held-out set you don't look at while
tuning. `search()` takes `keyword_weight` and `keyword_candidates` for
experiments.

## Layout

| File | Job |
|---|---|
| `vision/text.py` | word splitting, abbreviations, FTS query building |
| `vision/embed.py` | embedding model (loaded lazily) |
| `vision/db.py` | SQLite schema and inserts |
| `vision/indexer.py` | files → chunks → embeddings → database |
| `vision/search.py` | vector, keyword and hybrid (RRF) search, verdicts |
| `vision/graph.py` | resolves stored call sites to callers / callees |
| `vision/watch.py` | watch mode (watchdog → queue → re-index) |
| `vision/server.py` | MCP server: `search` and `remember` tools |
| `vision/evaluate.py` | benchmark metrics, runner and markdown report |
| `vision/cli.py` | the `vision` command |
| `tests/` | pytest suite |

When the schema changes, `SCHEMA_VERSION` in `db.py` is bumped and an
older database is rebuilt automatically (notes are carried over); run
`vision index` again afterwards.

## Tests

```powershell
pytest
```

Tests build small fake repos in temp folders and use the real model.
`tests/test_server.py` also launches `python -m vision serve` as a
subprocess and talks to it over stdio, just as Claude Code does.

## Known limitations

- Python only. Only functions are indexed; module-level code and class
  bodies aren't.
- The model reads at most 512 tokens, so very long functions are embedded
  from their start only (keyword search still sees all of the code).
- `STALE` is file-level: any edit in a file marks all its functions stale,
  even ones whose code didn't change (their line numbers may have moved).
- No way to edit or delete a note yet; notes can't be tied to one repo.
- The call graph doesn't know types: `obj.method()` with an unknown `obj`
  is a guess, and calls through variables (`handler = f; handler()`),
  decorators or `getattr` aren't seen.
- A schema upgrade re-inserts notes, so their `#id` numbers can change.

## License

MIT. See [LICENSE](LICENSE).
